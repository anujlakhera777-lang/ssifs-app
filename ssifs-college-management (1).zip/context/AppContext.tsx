import React, { createContext, useReducer, Dispatch, useEffect } from 'react';
import { User, Task, Notice, TimetableEntry, UserRole, TaskStatus, Query, QueryStatus, AcademicCalendarEvent, Exam, Result, Attendance, ClassroomMaterial, Syllabus } from '../types';
import { USERS, TASKS, NOTICES, TIMETABLE, QUERIES, ACADEMIC_CALENDAR_EVENTS, EXAMS, RESULTS, ATTENDANCE, CLASSROOM_MATERIALS, SYLLABUS_DATA } from '../constants';

interface AppState {
  users: User[];
  tasks: Task[];
  notices: Notice[];
  timetable: TimetableEntry[];
  queries: Query[];
  academicCalendar: AcademicCalendarEvent[];
  exams: Exam[];
  results: Result[];
  attendance: Attendance[];
  materials: ClassroomMaterial[];
  syllabus: Syllabus[];
  currentUser: User | null;
  notification: { message: string, type: 'success' | 'error', id: number } | null;
  theme: 'light' | 'dark';
}

type Action =
  | { type: 'LOGIN'; payload: { email: string; password: string; role: UserRole } }
  | { type: 'LOGOUT' }
  | { type: 'ADD_TASK'; payload: Task }
  | { type: 'UPDATE_TASK_STATUS'; payload: { taskId: string; status: TaskStatus } }
  | { type: 'ADD_NOTICE'; payload: Notice }
  | { type: 'DELETE_NOTICE'; payload: { noticeId: string } }
  | { type: 'ADD_USER'; payload: User }
  | { type: 'REMOVE_USER'; payload: { userId: string } }
  | { type: 'UPDATE_TIMETABLE'; payload: TimetableEntry }
  | { type: 'ADD_QUERY'; payload: Query }
  | { type: 'RESPOND_TO_QUERY'; payload: { queryId: string; response: string } }
  | { type: 'UPDATE_USER_PASSWORD'; payload: { userId: string; newPassword: string } }
  | { type: 'UPDATE_USER_ROLE'; payload: { userId: string; newRole: UserRole } }
  | { type: 'BULK_ADD_USERS'; payload: User[] }
  | { type: 'BULK_UPDATE_TIMETABLE'; payload: TimetableEntry[] }
  | { type: 'BULK_ADD_RESULTS'; payload: Result[] }
  | { type: 'ADD_ACADEMIC_EVENT'; payload: AcademicCalendarEvent }
  | { type: 'ADD_EXAM'; payload: Exam }
  | { type: 'ADD_RESULT'; payload: Result }
  | { type: 'MARK_ATTENDANCE'; payload: Attendance[] }
  | { type: 'UPLOAD_MATERIAL'; payload: ClassroomMaterial }
  | { type: 'SET_NOTIFICATION'; payload: { message: string; type: 'success' | 'error' } }
  | { type: 'CLEAR_NOTIFICATION' }
  | { type: 'TOGGLE_THEME' };

const LOCAL_STORAGE_KEY = 'ssifs-app-state';

const initialState: AppState = {
  users: USERS,
  tasks: TASKS,
  notices: NOTICES,
  timetable: TIMETABLE,
  queries: QUERIES,
  academicCalendar: ACADEMIC_CALENDAR_EVENTS,
  exams: EXAMS,
  results: RESULTS,
  attendance: ATTENDANCE,
  materials: CLASSROOM_MATERIALS,
  syllabus: SYLLABUS_DATA,
  currentUser: null,
  notification: null,
  theme: 'light',
};

const appReducer = (state: AppState, action: Action): AppState => {
  switch (action.type) {
    case 'LOGIN':
      const user = state.users.find(
        (u) => u.email === action.payload.email && u.role === action.payload.role && u.password === action.payload.password
      );
      return { ...state, currentUser: user || null };
    case 'LOGOUT':
      // Keep everything except currentUser and notification
      const persistentState = { ...state };
      delete persistentState.currentUser;
      delete persistentState.notification;
      return { ...initialState, ...persistentState, currentUser: null, notification: null };
    case 'ADD_TASK':
      return { ...state, tasks: [...state.tasks, action.payload] };
    case 'UPDATE_TASK_STATUS':
      return {
        ...state,
        tasks: state.tasks.map((task) =>
          task.id === action.payload.taskId ? { ...task, status: action.payload.status } : task
        ),
      };
    case 'ADD_NOTICE':
      return { ...state, notices: [action.payload, ...state.notices] };
    case 'DELETE_NOTICE':
      return { ...state, notices: state.notices.filter(n => n.id !== action.payload.noticeId) };
    case 'ADD_USER':
      return { ...state, users: [...state.users, action.payload] };
    case 'REMOVE_USER':
        return { ...state, users: state.users.filter(u => u.id !== action.payload.userId) };
    case 'UPDATE_TIMETABLE':
        // Simple add/replace for demo purposes
        const existingIndex = state.timetable.findIndex(t => t.id === action.payload.id);
        if (existingIndex > -1) {
            const newTimetable = [...state.timetable];
            newTimetable[existingIndex] = action.payload;
            return { ...state, timetable: newTimetable };
        }
        return { ...state, timetable: [...state.timetable, action.payload] };
    case 'ADD_QUERY':
        return { ...state, queries: [action.payload, ...state.queries] };
    case 'RESPOND_TO_QUERY':
        return {
            ...state,
            queries: state.queries.map(q =>
                q.id === action.payload.queryId
                    ? { ...q, status: QueryStatus.ANSWERED, response: action.payload.response }
                    : q
            ),
        };
    case 'UPDATE_USER_PASSWORD':
        const updatedUsers = state.users.map(user =>
            user.id === action.payload.userId
                ? { ...user, password: action.payload.newPassword }
                : user
        );
        const updatedCurrentUser = state.currentUser?.id === action.payload.userId
            ? { ...state.currentUser, password: action.payload.newPassword }
            : state.currentUser;
        return {
            ...state,
            users: updatedUsers,
            currentUser: updatedCurrentUser,
        };
     case 'UPDATE_USER_ROLE':
        return {
            ...state,
            users: state.users.map(user =>
                user.id === action.payload.userId
                    ? { ...user, role: action.payload.newRole }
                    : user
            ),
        };
    case 'BULK_ADD_USERS':
        const existingEmails = new Set(state.users.map(u => u.email));
        const newUsers = action.payload.filter(u => !existingEmails.has(u.email));
        return { ...state, users: [...state.users, ...newUsers]};
    case 'BULK_UPDATE_TIMETABLE':
        return { ...state, timetable: action.payload };
    case 'BULK_ADD_RESULTS':
        const newResults = [...state.results];
        action.payload.forEach(newResult => {
            const resIndex = newResults.findIndex(r => r.studentId === newResult.studentId && r.examId === newResult.examId);
            if(resIndex > -1) {
                newResults[resIndex] = newResult;
            } else {
                newResults.push(newResult);
            }
        });
        return { ...state, results: newResults };
     case 'ADD_ACADEMIC_EVENT':
      return { ...state, academicCalendar: [action.payload, ...state.academicCalendar] };
    case 'ADD_EXAM':
      return { ...state, exams: [action.payload, ...state.exams] };
    case 'ADD_RESULT':
       const addedResults = [...state.results.filter(r => !(r.studentId === action.payload.studentId && r.examId === action.payload.examId)), action.payload];
       return { ...state, results: addedResults };
    case 'MARK_ATTENDANCE':
      const newAttendance = [...state.attendance];
      action.payload.forEach(record => {
          const index = newAttendance.findIndex(a => a.studentId === record.studentId && a.date === record.date && a.subject === record.subject);
          if (index > -1) {
              newAttendance[index] = record;
          } else {
              newAttendance.push(record);
          }
      });
      return { ...state, attendance: newAttendance };
    case 'UPLOAD_MATERIAL':
      return { ...state, materials: [action.payload, ...state.materials] };
    case 'SET_NOTIFICATION':
        return { ...state, notification: { ...action.payload, id: Date.now() } };
    case 'CLEAR_NOTIFICATION':
        return { ...state, notification: null };
    case 'TOGGLE_THEME':
        return { ...state, theme: state.theme === 'light' ? 'dark' : 'light' };
    default:
      return state;
  }
};

export const AppContext = createContext<{
  state: AppState;
  dispatch: Dispatch<Action>;
}>({
  state: initialState,
  dispatch: () => null,
});

// Initializer function for useReducer to load state from localStorage
const init = (initialState: AppState): AppState => {
    try {
        const storedState = localStorage.getItem(LOCAL_STORAGE_KEY);
        if (storedState) {
            const parsedState = JSON.parse(storedState);
            // Don't persist notification state across reloads
            return { ...initialState, ...parsedState, notification: null };
        }
    } catch (e) {
        console.error("Failed to parse state from localStorage, using default state.", e);
    }
    return initialState;
};

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [state, dispatch] = useReducer(appReducer, initialState, init);

  // useEffect hook to save the state to localStorage whenever it changes.
  useEffect(() => {
    try {
        const stateToSave = { ...state, notification: null }; // Don't save notification
        localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(stateToSave));
    } catch (e) {
        console.error("Failed to save state to localStorage.", e);
    }
  }, [state]);

  return (
    <AppContext.Provider value={{ state, dispatch }}>
      {children}
    </AppContext.Provider>
  );
};