
import React from 'react';

const Logo: React.FC<{ className?: string }> = ({ className = '' }) => {
  return (
    <div className={`text-center ${className}`}>
      <h1 className="text-2xl font-bold tracking-wider text-gray-800 dark:text-gray-100">SSIFS</h1>
      <p className="text-xs text-gray-500 dark:text-gray-400 tracking-widest">SRI SRI INSTITUTE OF FASHION STUDIES</p>
    </div>
  );
};

export default Logo;