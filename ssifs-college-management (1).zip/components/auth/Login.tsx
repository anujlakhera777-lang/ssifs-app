
import React, { useState, useContext } from 'react';
import { AppContext } from '../../context/AppContext';
import { UserRole, User } from '../../types';

const Login: React.FC = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [role, setRole] = useState<UserRole>(UserRole.STUDENT);
  const [error, setError] = useState('');
  const [resetMessage, setResetMessage] = useState('');
  const [mode, setMode] = useState<'login' | 'register' | 'reset'>('login');
  
  const { state, dispatch } = useContext(AppContext);

  const handleModeChange = (newMode: 'login' | 'register' | 'reset') => {
      setError('');
      setResetMessage('');
      setEmail('');
      setPassword('');
      setName('');
      setMode(newMode);
  };

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    const userExists = state.users.some(u => u.email === email && u.role === role && u.password === password);
    if (userExists) {
      dispatch({ type: 'LOGIN', payload: { email, role, password } });
      setError('');
    } else {
      setError('Invalid credentials. Please check your details and try again.');
    }
  };
  
  const handlePasswordReset = (e: React.FormEvent) => {
    e.preventDefault();
    const userExists = state.users.some(u => u.email === email && u.role === role);
    setResetMessage('If an account exists for this email and role, password reset instructions have been sent.');
    setError('');
  };

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    const userExists = state.users.some(u => u.email === email && u.role === role);
    if (userExists) {
        setError(`An account with this email already exists for the ${role} role.`);
        return;
    }

    const newUser: User = {
        id: `${role.toLowerCase()}_${Date.now()}`,
        name,
        email,
        password,
        role,
    };

    dispatch({ type: 'ADD_USER', payload: newUser });
    dispatch({ type: 'SET_NOTIFICATION', payload: { message: 'Registration successful! You can now log in.', type: 'success' }});
    handleModeChange('login');
  }

  const commonFields = (
    <>
      <div>
        <label htmlFor="role" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
          I am a
        </label>
        <select
          id="role"
          value={role}
          onChange={(e) => {
            setRole(e.target.value as UserRole);
            setError('');
            setResetMessage('');
          }}
          className="mt-1 block w-full px-3 py-2 bg-white dark:bg-gray-700 dark:text-white border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
          aria-label="Select your role"
        >
          <option>{UserRole.STUDENT}</option>
          <option>{UserRole.STAFF}</option>
          <option>{UserRole.ADMIN}</option>
        </select>
      </div>
      <div>
        <label htmlFor="email" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
          Email Address
        </label>
        <input
          id="email"
          type="email"
          value={email}
          onChange={(e) => {
            setEmail(e.target.value);
            setError('');
            setResetMessage('');
          }}
          placeholder="e.g., chloe.d@ssifs.edu"
          required
          className="mt-1 block w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm placeholder-gray-400 dark:placeholder-gray-400 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 bg-white dark:bg-gray-700 dark:text-white"
          aria-required="true"
        />
      </div>
    </>
  );

  const renderForm = () => {
    switch(mode) {
        case 'register':
            return (
                <>
                    <h2 className="text-center text-2xl font-semibold text-gray-800 dark:text-gray-100 mb-6">Create Account</h2>
                    <form className="space-y-6" onSubmit={handleRegister}>
                        {commonFields}
                        <div>
                            <label htmlFor="name" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Full Name</label>
                            <input id="name" type="text" value={name} onChange={e => setName(e.target.value)} required placeholder="e.g. Alex Doe"
                                className="mt-1 block w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm placeholder-gray-400 dark:placeholder-gray-400 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 bg-white dark:bg-gray-700 dark:text-white" />
                        </div>
                        <div>
                            <label htmlFor="password-register" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Password</label>
                            <input id="password-register" type="password" value={password} onChange={e => setPassword(e.target.value)} required
                                className="mt-1 block w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm placeholder-gray-400 dark:placeholder-gray-400 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 bg-white dark:bg-gray-700 dark:text-white" />
                        </div>
                        {error && <p id="auth-error" className="text-sm text-red-600" role="alert">{error}</p>}
                        <div>
                            <button type="submit" className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition-colors">
                                Register
                            </button>
                        </div>
                        <div className="text-sm text-center">
                            <button type="button" onClick={() => handleModeChange('login')} className="font-medium text-indigo-600 hover:text-indigo-500 dark:text-indigo-400 dark:hover:text-indigo-300">
                                Already have an account? Login
                            </button>
                        </div>
                    </form>
                </>
            );
        case 'reset':
            return (
                <>
                    <h2 className="text-center text-2xl font-semibold text-gray-800 dark:text-gray-100 mb-6">Reset Password</h2>
                    <form className="space-y-6" onSubmit={handlePasswordReset}>
                        {commonFields}
                        {resetMessage && <p className="text-sm text-green-700" role="status">{resetMessage}</p>}
                        <div>
                            <button type="submit" className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition-colors">
                                Send Reset Link
                            </button>
                        </div>
                        <div className="text-sm text-center">
                            <button type="button" onClick={() => handleModeChange('login')} className="font-medium text-indigo-600 hover:text-indigo-500 dark:text-indigo-400 dark:hover:text-indigo-300">
                                Back to Login
                            </button>
                        </div>
                    </form>
                </>
            );
        case 'login':
        default:
            return (
                <>
                    <h2 className="text-center text-2xl font-semibold text-gray-800 dark:text-gray-100 mb-6">Welcome Back</h2>
                    <form className="space-y-6" onSubmit={handleLogin}>
                        {commonFields}
                        <div>
                            <label htmlFor="password" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Password</label>
                            <input id="password" type="password" value={password} onChange={e => setPassword(e.target.value)} required
                                className="mt-1 block w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm placeholder-gray-400 dark:placeholder-gray-400 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 bg-white dark:bg-gray-700 dark:text-white" />
                        </div>
                        {error && <p id="auth-error" className="text-sm text-red-600" role="alert">{error}</p>}
                        <div>
                            <button type="submit" className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition-colors">
                                Login
                            </button>
                        </div>
                        <div className="text-sm text-center flex justify-between items-center">
                            <button type="button" onClick={() => handleModeChange('reset')} className="font-medium text-indigo-600 hover:text-indigo-500 dark:text-indigo-400 dark:hover:text-indigo-300">
                                Forgot password?
                            </button>
                             <button type="button" onClick={() => handleModeChange('register')} className="font-medium text-indigo-600 hover:text-indigo-500 dark:text-indigo-400 dark:hover:text-indigo-300">
                                Sign Up
                            </button>
                        </div>
                    </form>
                </>
            );
    }
  }

  return (
    <div 
      className="relative min-h-screen flex items-center justify-center px-4 bg-gradient-to-br from-indigo-50 to-pink-50 dark:from-gray-900 dark:to-indigo-900"
    >
      <div className="relative w-full max-w-md space-y-8 text-center z-10">
        <div>
            <h1 className="text-5xl font-extrabold text-gray-800 dark:text-gray-100" style={{ fontFamily: "'Inter', sans-serif", letterSpacing: '0.15em' }}>SSIFS</h1>
            <p className="text-gray-600 dark:text-gray-300 tracking-[0.25em] text-xs mt-1 uppercase">Sri Sri Institute of Fashion Studies</p>
        </div>
        <div className="bg-white/95 dark:bg-gray-800/95 backdrop-blur-sm p-8 rounded-2xl shadow-2xl border border-gray-200/50 dark:border-gray-700/50 text-left">
            {renderForm()}
        </div>
      </div>
    </div>
  );
};

export default Login;