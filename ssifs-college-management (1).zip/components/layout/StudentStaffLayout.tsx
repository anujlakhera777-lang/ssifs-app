import React, { useState, useContext } from 'react';
import { AppContext } from '../../context/AppContext';
import { UserRole } from '../../types';

import StudentDashboard from '../../screens/student/StudentDashboard';
import StudentTimetable from '../../screens/student/StudentTimetable';
import StudentTasks from '../../screens/student/StudentTasks';
import StudentNotices from '../../screens/student/StudentNotices';
import Queries from '../../screens/common/Queries';
import Profile from '../../screens/common/Profile';

import StaffDashboard from '../../screens/staff/StaffDashboard';
import StaffTimetable from '../../screens/staff/StaffTimetable';
import StaffTasks from '../../screens/staff/StaffTasks';

import AcademicCalendar from '../../screens/common/AcademicCalendar';
import Exams from '../../screens/common/Exams';
import Attendance from '../../screens/common/Attendance';
import Materials from '../../screens/common/Materials';
import Syllabus from '../../screens/common/Syllabus';

type Screen = 'dashboard' | 'timetable' | 'tasks' | 'notices' | 'queries' | 'profile' | 'calendar' | 'exams' | 'attendance' | 'materials' | 'syllabus';

const StudentStaffLayout: React.FC = () => {
  const [activeScreen, setActiveScreen] = useState<Screen>('dashboard');
  const { state, dispatch } = useContext(AppContext);
  const { currentUser } = state;
  const isStudent = currentUser?.role === UserRole.STUDENT;

  const sharedNavItems = [
     { id: 'calendar', label: 'Calendar', icon: <BigCalendarIcon /> },
     { id: 'materials', label: 'Materials', icon: <FolderIcon /> },
     { id: 'syllabus', label: 'Syllabus', icon: <BookOpenIcon /> },
  ];

  const studentNavItems = [
    { id: 'dashboard', label: 'Home', icon: <HomeIcon /> },
    { id: 'timetable', label: 'Timetable', icon: <CalendarIcon /> },
    { id: 'tasks', label: 'Tasks', icon: <ClipboardIcon /> },
    { id: 'exams', label: 'Exams', icon: <DocumentReportIcon /> },
    { id: 'attendance', label: 'Attendance', icon: <UserGroupIcon /> },
    ...sharedNavItems.slice(0,1), // calendar
    { id: 'notices', label: 'Notices', icon: <MegaphoneIcon /> },
    ...sharedNavItems.slice(1), // materials, syllabus
    { id: 'queries', label: 'Queries', icon: <QuestionMarkIcon /> },
  ].filter((item, index, self) => index === self.findIndex(t => t.id === item.id));

  const staffNavItems = [
    { id: 'dashboard', label: 'Home', icon: <HomeIcon /> },
    { id: 'timetable', label: 'Timetable', icon: <CalendarIcon /> },
    { id: 'tasks', label: 'My Tasks', icon: <ClipboardIcon /> },
    { id: 'exams', label: 'Exams', icon: <DocumentReportIcon /> },
    { id: 'attendance', label: 'Attendance', icon: <UserGroupIcon /> },
     ...sharedNavItems,
    { id: 'queries', label: 'Queries', icon: <QuestionMarkIcon /> },
  ];
  
  const navItems = isStudent ? studentNavItems : staffNavItems;


  const renderScreen = () => {
    switch (activeScreen) {
      case 'dashboard':
        return isStudent ? <StudentDashboard /> : <StaffDashboard />;
      case 'timetable':
        return isStudent ? <StudentTimetable /> : <StaffTimetable />;
      case 'tasks':
        return isStudent ? <StudentTasks /> : <StaffTasks />;
      case 'queries':
        return <Queries />;
      case 'profile':
        return <Profile />;
      case 'calendar':
        return <AcademicCalendar />;
      case 'exams':
        return <Exams />;
      case 'attendance':
        return <Attendance />;
      case 'materials':
        return <Materials />;
      case 'syllabus':
        return <Syllabus />;
      case 'notices': // Only for students
        return isStudent ? <StudentNotices /> : <StaffDashboard />; // Fallback for staff
      default:
        return isStudent ? <StudentDashboard /> : <StaffDashboard />;
    }
  };

  return (
    <div className="flex flex-col h-screen bg-gray-50 dark:bg-gray-900">
      <header className="bg-white dark:bg-gray-800 h-20 border-b border-gray-200 dark:border-gray-700 flex items-center justify-between px-6 shadow-sm">
          <div>
            <h1 className="text-xl font-semibold text-gray-800 dark:text-gray-100">Welcome, {currentUser?.name?.split(' ')[0]}</h1>
            <p className="text-sm text-gray-500 dark:text-gray-400">{currentUser?.role} Portal</p>
          </div>
          <div className="flex items-center space-x-2">
            <button
                onClick={() => dispatch({ type: 'TOGGLE_THEME' })}
                className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700 text-gray-600 dark:text-gray-300 transition-colors"
                title="Toggle Theme"
                aria-label="Toggle Theme"
            >
                {state.theme === 'light' ? <MoonIcon /> : <SunIcon />}
            </button>
            <button
                onClick={() => setActiveScreen('profile')}
                className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
                title="My Profile"
                aria-label="My Profile"
            >
                <UserIcon />
            </button>
            <button
              onClick={() => dispatch({ type: 'LOGOUT' })}
              className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
              title="Logout"
              aria-label="Logout"
            >
              <LogoutIcon />
            </button>
          </div>
      </header>
      
      <main className="flex-1 overflow-y-auto p-4 md:p-6 pb-24">
        {renderScreen()}
      </main>

      <nav className="fixed bottom-0 left-0 right-0 bg-white dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700 flex justify-around h-16 shadow-top overflow-x-auto">
        {navItems.map((item) => (
          <button
            key={item.id}
            onClick={() => setActiveScreen(item.id as Screen)}
            className={`flex flex-col items-center justify-center w-full min-w-[70px] transition-colors group px-1 ${
              activeScreen === item.id ? 'text-indigo-600 dark:text-indigo-400' : 'text-gray-500 dark:text-gray-400 hover:text-indigo-600 dark:hover:text-indigo-400'
            }`}
          >
            <div className={`p-1 rounded-full transition-colors ${activeScreen === item.id ? 'bg-indigo-100 dark:bg-indigo-900/40' : 'bg-transparent'}`}>
             {item.icon}
            </div>
            <span className="text-xs font-medium mt-1">{item.label}</span>
          </button>
        ))}
      </nav>
    </div>
  );
};

// SVG Icons
const SunIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364 6.364l-.707-.707M6.343 6.343l-.707-.707m12.728 0l-.707.707M6.343 17.657l-.707.707M16 12a4 4 0 11-8 0 4 4 0 018 0z" /></svg>;
const MoonIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z" /></svg>;
const HomeIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" /></svg>;
const CalendarIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>;
const ClipboardIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01" /></svg>;
const LogoutIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-gray-600 dark:text-gray-300" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" /></svg>;
const MegaphoneIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M11 5.882V19.24a1.76 1.76 0 01-3.417.592l-2.147-6.136A7.757 7.757 0 013 12.24V12c0-3.417 1.659-6.46 4.2-8.242M11 5.882V5.882a4.5 4.5 0 014.288-4.135 4.5 4.5 0 014.534 4.135v.002c0 2.485-2.015 4.5-4.5 4.5h-.034" /></svg>;
const QuestionMarkIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M8.228 9c.549-1.165 2.03-2 3.772-2 2.21 0 4 1.79 4 4 0 2.21-1.79 4-4 4-1.742 0-3.223-.835-3.772-2M12 18.5v.01" /></svg>;
const UserIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-gray-600 dark:text-gray-300" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" /></svg>;

const BigCalendarIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2"><path strokeLinecap="round" strokeLinejoin="round" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>;
const DocumentReportIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2"><path strokeLinecap="round" strokeLinejoin="round" d="M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V7a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>;
const UserGroupIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2"><path strokeLinecap="round" strokeLinejoin="round" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.653-.124-1.282-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.653.124-1.282.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" /></svg>;
const FolderIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2"><path strokeLinecap="round" strokeLinejoin="round" d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-6l-2-2H5a2 2 0 00-2 2z" /></svg>;
const BookOpenIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2"><path strokeLinecap="round" strokeLinejoin="round" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.246 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" /></svg>;


export default StudentStaffLayout;