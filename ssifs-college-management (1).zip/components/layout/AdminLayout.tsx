import React, { useState, useContext } from 'react';
import { AppContext } from '../../context/AppContext';
import AdminDashboard from '../../screens/admin/AdminDashboard';
import AdminUserManagement from '../../screens/admin/AdminUserManagement';
import AdminTaskApproval from '../../screens/admin/AdminTaskApproval';
import AdminNotices from '../../screens/admin/AdminNotices';
import AdminTimetable from '../../screens/admin/AdminTimetable';
import Queries from '../../screens/common/Queries';
import Profile from '../../screens/common/Profile';
import Logo from '../common/Logo';
import AcademicCalendar from '../../screens/common/AcademicCalendar';
import Exams from '../../screens/common/Exams';
import Attendance from '../../screens/common/Attendance';
import Materials from '../../screens/common/Materials';
import Syllabus from '../../screens/common/Syllabus';

type AdminScreen = 'dashboard' | 'users' | 'tasks' | 'notices' | 'timetable' | 'queries' | 'profile' | 'calendar' | 'exams' | 'attendance' | 'materials' | 'syllabus';

const AdminLayout: React.FC = () => {
    const [activeScreen, setActiveScreen] = useState<AdminScreen>('dashboard');
    const [isSidebarOpen, setIsSidebarOpen] = useState(false); // Default closed on mobile
    const { state, dispatch } = useContext(AppContext);
    const { currentUser } = state;

    const navItems = [
        { id: 'dashboard', label: 'Dashboard', icon: <HomeIcon /> },
        { id: 'users', label: 'User Management', icon: <UsersIcon /> },
        { id: 'tasks', label: 'Task Approvals', icon: <CheckIcon /> },
        { id: 'notices', label: 'Notices', icon: <MegaphoneIcon /> },
        { id: 'timetable', label: 'Timetable', icon: <CalendarIcon /> },
        { id: 'calendar', label: 'Academic Calendar', icon: <BigCalendarIcon /> },
        { id: 'exams', label: 'Exams', icon: <DocumentReportIcon /> },
        { id: 'attendance', label: 'Attendance', icon: <UserGroupIcon /> },
        { id: 'materials', label: 'Materials', icon: <FolderIcon /> },
        { id: 'syllabus', label: 'Syllabus', icon: <BookOpenIcon /> },
        { id: 'queries', label: 'Queries', icon: <QuestionMarkIcon /> },
    ];
    
    const renderScreen = () => {
        switch (activeScreen) {
            case 'dashboard': return <AdminDashboard />;
            case 'users': return <AdminUserManagement />;
            case 'tasks': return <AdminTaskApproval />;
            case 'notices': return <AdminNotices />;
            case 'timetable': return <AdminTimetable />;
            case 'queries': return <Queries />;
            case 'profile': return <Profile />;
            case 'calendar': return <AcademicCalendar />;
            case 'exams': return <Exams />;
            case 'attendance': return <Attendance />;
            case 'materials': return <Materials />;
            case 'syllabus': return <Syllabus />;
            default: return <AdminDashboard />;
        }
    };

    const getScreenTitle = () => {
        if (activeScreen === 'profile') return 'My Profile';
        const currentItem = navItems.find(item => item.id === activeScreen);
        return currentItem ? currentItem.label : 'Dashboard';
    }

    return (
        <div className="relative min-h-screen md:flex bg-gray-100 dark:bg-gray-900">
            {/* Mobile menu overlay */}
            {isSidebarOpen && (
                 <div 
                    className="fixed inset-0 bg-black bg-opacity-50 z-20 md:hidden" 
                    onClick={() => setIsSidebarOpen(false)}
                    aria-hidden="true"
                ></div>
            )}

            {/* Sidebar */}
            <aside className={`fixed inset-y-0 left-0 bg-white dark:bg-gray-800 border-r border-gray-200 dark:border-gray-700 w-64 transform ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'} md:relative md:translate-x-0 transition-transform duration-300 ease-in-out z-30 flex flex-col flex-shrink-0`}>
                <div className="h-20 flex items-center justify-center border-b border-gray-200 dark:border-gray-700 flex-shrink-0">
                    <Logo />
                </div>
                <nav className="flex-1 px-4 py-6 space-y-2 overflow-y-auto">
                    {navItems.map(item => (
                        <button
                            key={item.id}
                            onClick={() => {
                                setActiveScreen(item.id as AdminScreen)
                                setIsSidebarOpen(false); // Close sidebar on selection
                            }}
                            className={`w-full flex items-center px-4 py-2.5 text-sm font-medium rounded-lg transition-colors group ${
                                activeScreen === item.id 
                                ? 'bg-indigo-600 text-white shadow-md' 
                                : 'text-gray-600 dark:text-gray-300 hover:bg-indigo-50 dark:hover:bg-gray-700 hover:text-indigo-600 dark:hover:text-white'
                            }`}
                        >
                            <span className={`w-5 h-5 ${activeScreen === item.id ? 'text-white' : 'text-gray-400 dark:text-gray-500 group-hover:text-indigo-600 dark:group-hover:text-white'}`}>{item.icon}</span>
                            <span className="ml-3">{item.label}</span>
                        </button>
                    ))}
                </nav>
            </aside>

            <div className="flex-1 flex flex-col overflow-hidden">
                <header className="bg-white dark:bg-gray-800 h-20 border-b border-gray-200 dark:border-gray-700 flex items-center justify-between px-4 sm:px-8 flex-shrink-0">
                    <div className="flex items-center">
                         <button 
                            onClick={() => setIsSidebarOpen(true)} 
                            className="md:hidden mr-4 text-gray-600 dark:text-gray-300 hover:text-gray-800 dark:hover:text-white"
                            aria-label="Open sidebar"
                        >
                           <MenuIcon />
                        </button>
                        <h1 className="text-xl font-semibold text-gray-800 dark:text-gray-100 capitalize">{getScreenTitle()}</h1>
                    </div>
                    <div className="flex items-center space-x-2 sm:space-x-4">
                        <button
                            onClick={() => dispatch({ type: 'TOGGLE_THEME' })}
                            className="p-2 rounded-full text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
                            title="Toggle Theme"
                            aria-label="Toggle Theme"
                        >
                            {state.theme === 'light' ? <MoonIcon /> : <SunIcon />}
                        </button>
                        <div className="text-right hidden sm:block">
                            <div className="font-medium text-gray-700 dark:text-gray-200">{currentUser?.name}</div>
                            <div className="text-xs text-gray-500 dark:text-gray-400">{currentUser?.role}</div>
                        </div>
                        <button
                            onClick={() => setActiveScreen('profile')}
                            className="p-2 rounded-full text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
                            title="My Profile"
                            aria-label="My Profile"
                        >
                           <UserIcon />
                        </button>
                        <button
                            onClick={() => dispatch({ type: 'LOGOUT' })}
                            className="p-2 rounded-full text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
                            title="Logout"
                            aria-label="Logout"
                        >
                            <LogoutIcon />
                        </button>
                    </div>
                </header>
                <main className="flex-1 overflow-y-auto p-4 sm:p-8 bg-gray-50 dark:bg-gray-950">
                    {renderScreen()}
                </main>
            </div>
        </div>
    );
};

// SVG Icons
const HomeIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-full w-full" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" /></svg>;
const UsersIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-full w-full" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M15 21a6 6 0 00-9-5.197M15 21a6 6 0 00-9-5.197" /></svg>;
const CheckIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-full w-full" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>;
const MegaphoneIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-full w-full" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5.882V19.24a1.76 1.76 0 01-3.417.592l-2.147-6.136A7.757 7.757 0 013 12.24V12c0-3.417 1.659-6.46 4.2-8.242M11 5.882V5.882a4.5 4.5 0 014.288-4.135 4.5 4.5 0 014.534 4.135v.002c0 2.485-2.015 4.5-4.5 4.5h-.034" /></svg>;
const CalendarIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-full w-full" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>;
const QuestionMarkIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-full w-full" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M8.228 9c.549-1.165 2.03-2 3.772-2 2.21 0 4 1.79 4 4 0 2.21-1.79 4-4 4-1.742 0-3.223-.835-3.772-2M12 18.5v.01" /></svg>;
const LogoutIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" /></svg>;
const MenuIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" /></svg>;
const UserIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" /></svg>;
const SunIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364 6.364l-.707-.707M6.343 6.343l-.707-.707m12.728 0l-.707.707M6.343 17.657l-.707.707M16 12a4 4 0 11-8 0 4 4 0 018 0z" /></svg>;
const MoonIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z" /></svg>;

const BigCalendarIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-full w-full" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2"><path strokeLinecap="round" strokeLinejoin="round" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>;
const DocumentReportIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-full w-full" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2"><path strokeLinecap="round" strokeLinejoin="round" d="M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V7a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>;
const UserGroupIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-full w-full" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2"><path strokeLinecap="round" strokeLinejoin="round" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.653-.124-1.282-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.653.124-1.282.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" /></svg>;
const FolderIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-full w-full" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2"><path strokeLinecap="round" strokeLinejoin="round" d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-6l-2-2H5a2 2 0 00-2 2z" /></svg>;
const BookOpenIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-full w-full" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2"><path strokeLinecap="round" strokeLinejoin="round" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.246 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" /></svg>;


export default AdminLayout;