import React, { useContext, useState, useMemo } from 'react';
import { AppContext } from '../../context/AppContext';
import { UserRole, Attendance as AttendanceType } from '../../types';
import Card from '../../components/common/Card';

const Attendance: React.FC = () => {
    const { state, dispatch } = useContext(AppContext);
    const { currentUser, users, timetable, attendance } = state;

    const isStudent = currentUser?.role === UserRole.STUDENT;
    const isStaff = currentUser?.role === UserRole.STAFF;

    // Staff state
    const today = new Date().toISOString().split('T')[0];
    const [selectedDate, setSelectedDate] = useState(today);
    const [selectedSubject, setSelectedSubject] = useState('');
    const [studentAttendance, setStudentAttendance] = useState<Record<string, 'Present' | 'Absent'>>({});

    const mySubjects = useMemo(() => {
        return [...new Set(timetable.filter(t => t.assignedTo === currentUser?.id).map(t => t.subject))];
    }, [timetable, currentUser]);

    const allStudents = useMemo(() => users.filter(u => u.role === UserRole.STUDENT), [users]);
    
    const handleAttendanceChange = (studentId: string, status: 'Present' | 'Absent') => {
        setStudentAttendance(prev => ({ ...prev, [studentId]: status }));
    };

    const handleMarkAttendance = () => {
        const attendanceRecords: AttendanceType[] = Object.entries(studentAttendance).map(([studentId, status]) => ({
            studentId,
            date: selectedDate,
            subject: selectedSubject,
            status,
        }));
        
        dispatch({ type: 'MARK_ATTENDANCE', payload: attendanceRecords });
        dispatch({ type: 'SET_NOTIFICATION', payload: { message: 'Attendance marked successfully!', type: 'success' } });
        setStudentAttendance({});
        setSelectedSubject('');
    };

    // Student state
    const studentAttendanceData = useMemo(() => {
        if (!isStudent) return {};
        const myAttendance = attendance.filter(a => a.studentId === currentUser?.id);
        const subjects = [...new Set(myAttendance.map(a => a.subject))];
        const stats: Record<string, { present: number, total: number }> = {};
        
        subjects.forEach(subject => {
            const subjectRecords = myAttendance.filter(a => a.subject === subject);
            const presentCount = subjectRecords.filter(a => a.status === 'Present').length;
            stats[subject] = { present: presentCount, total: subjectRecords.length };
        });
        return stats;
    }, [attendance, currentUser, isStudent]);


    const renderStudentView = () => (
        <div className="space-y-6">
            <h2 className="text-2xl font-semibold text-gray-800 dark:text-gray-100">My Attendance</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {Object.entries(studentAttendanceData).map(([subject, stats]) => {
                    const percentage = stats.total > 0 ? Math.round((stats.present / stats.total) * 100) : 0;
                    const color = percentage >= 75 ? 'bg-green-500' : percentage >= 50 ? 'bg-yellow-500' : 'bg-red-500';

                    return (
                        <Card key={subject}>
                            <h3 className="font-semibold text-lg text-gray-800 dark:text-gray-100">{subject}</h3>
                            <p className="text-sm text-gray-500 dark:text-gray-400">{stats.present} / {stats.total} classes attended</p>
                            <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2.5 mt-3">
                                <div className={`${color} h-2.5 rounded-full`} style={{ width: `${percentage}%` }}></div>
                            </div>
                            <p className="text-right font-bold text-xl mt-2 dark:text-gray-200">{percentage}%</p>
                        </Card>
                    );
                })}
            </div>
            {Object.keys(studentAttendanceData).length === 0 && <Card><p className="text-center text-gray-500 dark:text-gray-400">No attendance records found.</p></Card>}
        </div>
    );

    const renderStaffView = () => (
         <div className="space-y-6">
            <h2 className="text-2xl font-semibold text-gray-800 dark:text-gray-100">Mark Attendance</h2>
            <Card>
                <div className="flex flex-wrap gap-4 items-end">
                    <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Date</label>
                        <input type="date" value={selectedDate} onChange={e => setSelectedDate(e.target.value)} className="mt-1 block w-full border-gray-300 dark:border-gray-600 rounded-md shadow-sm bg-white dark:bg-gray-700 dark:text-white" />
                    </div>
                     <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Subject</label>
                        <select value={selectedSubject} onChange={e => setSelectedSubject(e.target.value)} className="mt-1 block w-full border-gray-300 dark:border-gray-600 rounded-md shadow-sm py-2 px-3 bg-white dark:bg-gray-700 dark:text-white">
                            <option value="">Select Subject</option>
                            {mySubjects.map(s => <option key={s} value={s}>{s}</option>)}
                        </select>
                    </div>
                </div>
            </Card>

            {selectedSubject && (
                <Card>
                    <h3 className="font-semibold mb-4 dark:text-gray-200">Students List for {selectedSubject}</h3>
                    <div className="space-y-3">
                        {allStudents.map(student => (
                            <div key={student.id} className="flex justify-between items-center p-3 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
                                <p className="font-medium dark:text-gray-200">{student.name}</p>
                                <div className="flex items-center space-x-2">
                                    <button onClick={() => handleAttendanceChange(student.id, 'Present')} className={`px-3 py-1 text-sm rounded-md ${studentAttendance[student.id] === 'Present' ? 'bg-green-600 text-white' : 'bg-gray-200 dark:bg-gray-600 dark:text-gray-200'}`}>Present</button>
                                    <button onClick={() => handleAttendanceChange(student.id, 'Absent')} className={`px-3 py-1 text-sm rounded-md ${studentAttendance[student.id] === 'Absent' ? 'bg-red-600 text-white' : 'bg-gray-200 dark:bg-gray-600 dark:text-gray-200'}`}>Absent</button>
                                </div>
                            </div>
                        ))}
                    </div>
                    <button onClick={handleMarkAttendance} className="w-full mt-6 bg-indigo-600 text-white py-2 rounded-lg font-semibold hover:bg-indigo-700">Submit Attendance</button>
                </Card>
            )}
        </div>
    );
    
    // Admin or other roles can have a view-only version
    const renderDefaultView = () => (
        <Card>
            <p className="text-center text-gray-500 dark:text-gray-400">Attendance management is available for Staff. Students can view their records.</p>
        </Card>
    );


    if (isStudent) return renderStudentView();
    if (isStaff) return renderStaffView();
    return renderDefaultView();
};

export default Attendance;