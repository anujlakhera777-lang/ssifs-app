import React, { useContext, useState, useMemo } from 'react';
import { AppContext } from '../../context/AppContext';
import { AcademicCalendarEvent, EventType, UserRole } from '../../types';
import Card from '../../components/common/Card';

const AcademicCalendar: React.FC = () => {
    const { state, dispatch } = useContext(AppContext);
    const { currentUser, academicCalendar } = state;

    const [title, setTitle] = useState('');
    const [date, setDate] = useState('');
    const [type, setType] = useState<EventType>(EventType.EVENT);

    const isAdmin = currentUser?.role === UserRole.ADMIN;

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!title || !date || !type) return;

        const newEvent: AcademicCalendarEvent = {
            id: `ace_${Date.now()}`,
            title,
            date,
            type,
        };

        dispatch({ type: 'ADD_ACADEMIC_EVENT', payload: newEvent });
        dispatch({ type: 'SET_NOTIFICATION', payload: { message: 'Event added to calendar!', type: 'success' } });
        setTitle('');
        setDate('');
        setType(EventType.EVENT);
    };

    const eventsByMonth = useMemo(() => {
        const sortedEvents = [...academicCalendar].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
        return sortedEvents.reduce((acc, event) => {
            const month = new Date(event.date).toLocaleString('default', { month: 'long', year: 'numeric' });
            if (!acc[month]) {
                acc[month] = [];
            }
            acc[month].push(event);
            return acc;
        }, {} as Record<string, AcademicCalendarEvent[]>);
    }, [academicCalendar]);

    const getTypeStyles = (type: EventType) => {
        switch (type) {
            case EventType.HOLIDAY: return 'border-red-400 bg-red-50 dark:bg-red-900/40 dark:border-red-700';
            case EventType.EXAM: return 'border-yellow-400 bg-yellow-50 dark:bg-yellow-900/40 dark:border-yellow-700';
            case EventType.EVENT: return 'border-indigo-400 bg-indigo-50 dark:bg-indigo-900/40 dark:border-indigo-700';
            case EventType.WORKSHOP: return 'border-green-400 bg-green-50 dark:bg-green-900/40 dark:border-green-700';
            default: return 'border-gray-300 bg-gray-50 dark:bg-gray-700/40 dark:border-gray-600';
        }
    };

    return (
        <div className="space-y-6">
            <h2 className="text-2xl font-semibold text-gray-800 dark:text-gray-100">Academic Calendar</h2>

            {isAdmin && (
                <Card>
                    <form onSubmit={handleSubmit} className="space-y-4">
                        <h3 className="text-lg font-semibold dark:text-gray-200">Add Calendar Event</h3>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                             <div>
                                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Title</label>
                                <input type="text" value={title} onChange={e => setTitle(e.target.value)} required className="mt-1 block w-full border-gray-300 dark:border-gray-600 rounded-md shadow-sm bg-white dark:bg-gray-700 dark:text-white" />
                            </div>
                             <div>
                                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Date</label>
                                <input type="date" value={date} onChange={e => setDate(e.target.value)} required className="mt-1 block w-full border-gray-300 dark:border-gray-600 rounded-md shadow-sm bg-white dark:bg-gray-700 dark:text-white" />
                            </div>
                             <div>
                                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Type</label>
                                <select value={type} onChange={e => setType(e.target.value as EventType)} required className="mt-1 block w-full border-gray-300 dark:border-gray-600 rounded-md shadow-sm py-2 px-3 bg-white dark:bg-gray-700 dark:text-white">
                                    {Object.values(EventType).map(t => <option key={t} value={t}>{t}</option>)}
                                </select>
                            </div>
                        </div>
                        <button type="submit" className="w-full md:w-auto bg-indigo-600 text-white py-2 px-6 rounded-lg font-semibold hover:bg-indigo-700">Add Event</button>
                    </form>
                </Card>
            )}

            <div className="space-y-8">
                {Object.keys(eventsByMonth).length > 0 ? (
                    Object.entries(eventsByMonth).map(([month, events]) => (
                        <Card key={month}>
                            <h3 className="text-xl font-bold text-gray-700 dark:text-gray-200 mb-4">{month}</h3>
                            <div className="space-y-3">
                                {events.map(event => (
                                    <div key={event.id} className={`p-3 rounded-lg border-l-4 ${getTypeStyles(event.type)}`}>
                                        <div className="flex items-center justify-between">
                                            <div>
                                                <p className="font-semibold text-gray-800 dark:text-gray-100">{event.title}</p>
                                                <p className="text-sm text-gray-500 dark:text-gray-400">{new Date(event.date).toLocaleDateString(undefined, { weekday: 'long', day: 'numeric' })}</p>
                                            </div>
                                            <span className="text-xs font-medium bg-white text-gray-700 dark:bg-gray-700 dark:text-gray-200 px-2 py-1 rounded-full border border-gray-200 dark:border-gray-600">{event.type}</span>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </Card>
                    ))
                ) : (
                    <Card>
                        <p className="text-center text-gray-500 dark:text-gray-400 py-8">The academic calendar is empty.</p>
                    </Card>
                )}
            </div>
        </div>
    );
};

export default AcademicCalendar;