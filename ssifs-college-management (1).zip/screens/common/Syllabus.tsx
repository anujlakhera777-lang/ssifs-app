import React, { useContext, useState } from 'react';
import { AppContext } from '../../context/AppContext';
import Card from '../../components/common/Card';

const Syllabus: React.FC = () => {
    const { state } = useContext(AppContext);
    const { syllabus } = state;
    const [selectedSubject, setSelectedSubject] = useState<string | null>(syllabus[0]?.id || null);

    const subject = syllabus.find(s => s.id === selectedSubject);

    return (
        <div className="space-y-6">
            <h2 className="text-2xl font-semibold text-gray-800 dark:text-gray-100">Course Syllabus</h2>

            <div className="flex flex-wrap gap-2">
                {syllabus.map(s => (
                    <button 
                        key={s.id}
                        onClick={() => setSelectedSubject(s.id)}
                        className={`px-4 py-2 rounded-full text-sm font-semibold transition-colors ${selectedSubject === s.id ? 'bg-indigo-600 text-white' : 'bg-white dark:bg-gray-700 text-gray-700 dark:text-gray-200 hover:bg-indigo-50 dark:hover:bg-gray-600'}`}
                    >
                        {s.subject}
                    </button>
                ))}
            </div>

            {subject ? (
                <Card>
                    <h3 className="text-xl font-bold text-gray-800 dark:text-gray-100 mb-4">{subject.subject}</h3>
                    <div className="space-y-6">
                        {subject.modules.map((module, index) => (
                            <div key={index}>
                                <h4 className="font-semibold text-lg text-indigo-700 dark:text-indigo-400">{module.title}</h4>
                                <ul className="list-disc list-inside mt-2 space-y-1 text-gray-600 dark:text-gray-300">
                                    {module.topics.map((topic, topicIndex) => (
                                        <li key={topicIndex}>{topic}</li>
                                    ))}
                                </ul>
                            </div>
                        ))}
                    </div>
                </Card>
            ) : (
                 <Card>
                    <p className="text-center text-gray-500 dark:text-gray-400 py-8">Select a subject to view its syllabus.</p>
                 </Card>
            )}
        </div>
    );
};

export default Syllabus;