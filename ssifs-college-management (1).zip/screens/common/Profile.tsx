import React, { useContext, useState } from 'react';
import { AppContext } from '../../context/AppContext';
import Card from '../../components/common/Card';

const Profile: React.FC = () => {
    const { state, dispatch } = useContext(AppContext);
    const { currentUser } = state;

    const [isEditing, setIsEditing] = useState(false);
    const [currentPassword, setCurrentPassword] = useState('');
    const [newPassword, setNewPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');

    if (!currentUser) {
        return null; // Or a loading/error state
    }
    
    const handleToggleEdit = () => {
        setIsEditing(!isEditing);
        // Reset fields when closing edit mode
        if (isEditing) {
            setCurrentPassword('');
            setNewPassword('');
            setConfirmPassword('');
        }
    };

    const handleSaveChanges = (e: React.FormEvent) => {
        e.preventDefault();

        if (currentPassword !== currentUser.password) {
            dispatch({ type: 'SET_NOTIFICATION', payload: { message: 'Incorrect current password.', type: 'error' } });
            return;
        }

        if (!newPassword) {
            dispatch({ type: 'SET_NOTIFICATION', payload: { message: 'New password cannot be empty.', type: 'error' } });
            return;
        }

        if (newPassword !== confirmPassword) {
            dispatch({ type: 'SET_NOTIFICATION', payload: { message: 'New passwords do not match.', type: 'error' } });
            return;
        }

        dispatch({ type: 'UPDATE_USER_PASSWORD', payload: { userId: currentUser.id, newPassword: newPassword } });
        dispatch({ type: 'SET_NOTIFICATION', payload: { message: 'Password updated successfully!', type: 'success' } });
        
        handleToggleEdit(); // Exit edit mode
    };

    const renderEditForm = () => (
        <div className="mt-6 pt-6 border-t border-gray-200 dark:border-gray-700">
            <h4 className="text-lg font-semibold text-gray-700 dark:text-gray-200 mb-4">Change Password</h4>
            <form onSubmit={handleSaveChanges} className="space-y-4">
                 <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Current Password</label>
                    <input type="password" value={currentPassword} onChange={e => setCurrentPassword(e.target.value)} required className="mt-1 block w-full border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 bg-white dark:bg-gray-700 dark:text-white" />
                </div>
                <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">New Password</label>
                    <input type="password" value={newPassword} onChange={e => setNewPassword(e.target.value)} required className="mt-1 block w-full border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 bg-white dark:bg-gray-700 dark:text-white" />
                </div>
                 <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Confirm New Password</label>
                    <input type="password" value={confirmPassword} onChange={e => setConfirmPassword(e.target.value)} required className="mt-1 block w-full border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 bg-white dark:bg-gray-700 dark:text-white" />
                </div>
                <div className="flex justify-end space-x-3 pt-2">
                     <button
                        type="button"
                        onClick={handleToggleEdit}
                        className="px-6 py-2 bg-gray-200 text-gray-700 font-semibold rounded-lg hover:bg-gray-300 dark:bg-gray-600 dark:text-gray-200 dark:hover:bg-gray-500 transition-colors"
                    >
                        Cancel
                    </button>
                    <button
                        type="submit"
                        className="px-6 py-2 bg-indigo-600 text-white font-semibold rounded-lg hover:bg-indigo-700 transition-colors shadow-sm"
                    >
                        Save Changes
                    </button>
                </div>
            </form>
        </div>
    );

    return (
        <div className="space-y-6 max-w-2xl mx-auto">
            <div>
                <h2 className="text-2xl font-semibold text-gray-800 dark:text-gray-100 mb-4">My Profile</h2>
            </div>
            <Card>
                <div className="flex flex-col items-center sm:flex-row sm:items-start text-center sm:text-left">
                    <div className="flex-shrink-0 mb-4 sm:mb-0 sm:mr-6">
                        <div className="w-24 h-24 bg-indigo-100 dark:bg-gray-700 rounded-full flex items-center justify-center text-indigo-500 dark:text-indigo-400">
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                            </svg>
                        </div>
                    </div>
                    <div className="flex-1 w-full">
                        <h3 className="text-2xl font-bold text-gray-800 dark:text-gray-100">{currentUser.name}</h3>
                        <p className="text-md text-gray-500 dark:text-gray-400">{currentUser.email}</p>
                        <span className="mt-2 inline-block bg-indigo-100 text-indigo-800 dark:bg-indigo-900 dark:text-indigo-200 text-xs font-semibold px-2.5 py-0.5 rounded-full">{currentUser.role}</span>
                        
                        {!isEditing && (
                             <div className="mt-6">
                                <button
                                    onClick={handleToggleEdit}
                                    className="px-6 py-2 bg-indigo-600 text-white font-semibold rounded-lg hover:bg-indigo-700 transition-colors shadow-sm"
                                >
                                    Edit Profile
                                </button>
                            </div>
                        )}
                    </div>
                </div>
                {isEditing && renderEditForm()}
            </Card>
        </div>
    );
};

export default Profile;