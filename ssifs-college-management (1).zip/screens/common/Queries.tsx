
import React, { useContext, useState } from 'react';
import { AppContext } from '../../context/AppContext';
import { Query, UserRole, QueryStatus } from '../../types';
import Card from '../../components/common/Card';

const Queries: React.FC = () => {
    const { state, dispatch } = useContext(AppContext);
    const { currentUser, users, queries } = state;

    const isStudent = currentUser?.role === UserRole.STUDENT;

    // State for the new query form (for students)
    const [recipient, setRecipient] = useState('');
    const [subject, setSubject] = useState('');
    const [question, setQuestion] = useState('');
    const [showForm, setShowForm] = useState(false);

    // State for responding to a query (for staff/admin)
    const [response, setResponse] = useState('');
    const [respondingTo, setRespondingTo] = useState<string | null>(null);

    const facultyAndAdmin = users.filter(u => u.role === UserRole.STAFF || u.role === UserRole.ADMIN);

    const handleRaiseQuery = (e: React.FormEvent) => {
        e.preventDefault();
        if (!recipient || !subject || !question || !currentUser) return;

        const recipientUser = users.find(u => u.id === recipient);
        
        const newQuery: Query = {
            id: `query_${Date.now()}`,
            studentId: currentUser.id,
            studentName: currentUser.name,
            recipientId: recipient,
            recipientName: recipient === 'all_faculty' ? 'All Faculty/Admin' : recipientUser?.name || 'Admin',
            subject,
            question,
            status: QueryStatus.PENDING,
            createdAt: new Date().toISOString().split('T')[0],
        };
        dispatch({ type: 'ADD_QUERY', payload: newQuery });
        dispatch({ type: 'SET_NOTIFICATION', payload: { message: 'Query submitted successfully!', type: 'success' } });
        setRecipient('');
        setSubject('');
        setQuestion('');
        setShowForm(false);
    };

    const handleRespond = (queryId: string) => {
        if (!response) return;
        dispatch({ type: 'RESPOND_TO_QUERY', payload: { queryId, response } });
        dispatch({ type: 'SET_NOTIFICATION', payload: { message: 'Response sent!', type: 'success' } });
        setResponse('');
        setRespondingTo(null);
    }

    const studentQueries = queries.filter(q => q.studentId === currentUser?.id).sort((a,b) => b.createdAt.localeCompare(a.createdAt));
    
    const staffAdminQueries = queries.filter(q => {
        if (currentUser?.role === UserRole.ADMIN) {
            // Admin sees queries to admin, and 'all faculty'
            return q.recipientId === currentUser.id || q.recipientId === 'admin01' || q.recipientId === 'all_faculty';
        }
        if (currentUser?.role === UserRole.STAFF) {
            // Staff sees queries to them, and 'all faculty'
            return q.recipientId === currentUser.id || q.recipientId === 'all_faculty';
        }
        return false;
    }).sort((a,b) => b.createdAt.localeCompare(a.createdAt));


    const renderStudentView = () => (
        <div className="space-y-6">
            <div className="flex justify-between items-center">
                <h2 className="text-2xl font-semibold text-gray-800 dark:text-gray-100">My Queries</h2>
                <button
                    onClick={() => setShowForm(!showForm)}
                    className="bg-indigo-600 text-white px-4 py-2 rounded-lg font-semibold hover:bg-indigo-700 transition-colors"
                >
                    {showForm ? 'Cancel' : '+ Raise a Query'}
                </button>
            </div>

            {showForm && (
                <Card>
                    <form onSubmit={handleRaiseQuery} className="space-y-4">
                        <h3 className="text-lg font-semibold dark:text-gray-200">New Query</h3>
                        <div>
                            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">To</label>
                            <select value={recipient} onChange={e => setRecipient(e.target.value)} required className="mt-1 block w-full border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 py-2 px-3 bg-white dark:bg-gray-700 dark:text-white">
                                <option value="">Select Recipient</option>
                                <option value="admin01">Admin</option>
                                <option value="all_faculty">All Faculty/Admin</option>
                                {users.filter(u => u.role === UserRole.STAFF).map(staff => (
                                    <option key={staff.id} value={staff.id}>{staff.name}</option>
                                ))}
                            </select>
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Subject</label>
                            <input type="text" value={subject} onChange={e => setSubject(e.target.value)} required className="mt-1 block w-full border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 bg-white dark:bg-gray-700 dark:text-white" />
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Question</label>
                            <textarea rows={4} value={question} onChange={e => setQuestion(e.target.value)} required className="mt-1 block w-full border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 bg-white dark:bg-gray-700 dark:text-white" />
                        </div>
                        <button type="submit" className="w-full bg-indigo-600 text-white py-2 rounded-lg font-semibold hover:bg-indigo-700">Submit Query</button>
                    </form>
                </Card>
            )}

            <div className="space-y-4">
                <h3 className="text-xl font-semibold text-gray-700 dark:text-gray-200">Query History</h3>
                 {studentQueries.length > 0 ? studentQueries.map(q => (
                    <Card key={q.id}>
                        <div className="flex justify-between items-start">
                           <div>
                                <h4 className="font-semibold dark:text-gray-100">{q.subject}</h4>
                                <p className="text-sm text-gray-500 dark:text-gray-400">To: {q.recipientName} on {q.createdAt}</p>
                           </div>
                           <span className={`px-2 py-1 text-xs font-semibold rounded-full ${q.status === QueryStatus.PENDING ? 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200' : 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200'}`}>
                               {q.status}
                           </span>
                        </div>
                        <p className="mt-3 text-gray-600 dark:text-gray-300 italic">"{q.question}"</p>
                        {q.response && (
                             <div className="mt-4 pt-3 border-t border-gray-200 dark:border-gray-600">
                                <p className="font-semibold text-indigo-700 dark:text-indigo-400">Response:</p>
                                <p className="text-gray-600 dark:text-gray-300">{q.response}</p>
                             </div>
                        )}
                    </Card>
                )) : <Card><p className="text-center text-gray-500 dark:text-gray-400">No queries raised yet.</p></Card>}
            </div>
        </div>
    );

    const renderStaffAdminView = () => (
        <div className="space-y-6">
            <h2 className="text-2xl font-semibold text-gray-800 dark:text-gray-100">Student Queries</h2>
            <div className="space-y-4">
                {staffAdminQueries.length > 0 ? staffAdminQueries.map(q => (
                    <Card key={q.id}>
                         <div className="flex justify-between items-start">
                           <div>
                                <h4 className="font-semibold dark:text-gray-100">{q.subject}</h4>
                                <p className="text-sm text-gray-500 dark:text-gray-400">From: {q.studentName} on {q.createdAt}</p>
                           </div>
                           <span className={`px-2 py-1 text-xs font-semibold rounded-full ${q.status === QueryStatus.PENDING ? 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200' : 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200'}`}>
                               {q.status}
                           </span>
                        </div>
                        <p className="mt-3 text-gray-600 dark:text-gray-300 italic">"{q.question}"</p>

                        {q.status === QueryStatus.PENDING && (
                            <div className="mt-4 pt-3 border-t border-gray-200 dark:border-gray-600">
                                {respondingTo === q.id ? (
                                    <div className="space-y-2">
                                        <textarea 
                                            rows={3} 
                                            value={response} 
                                            onChange={e => setResponse(e.target.value)} 
                                            placeholder="Type your response here..."
                                            className="block w-full border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 bg-white dark:bg-gray-700 dark:text-white"
                                        />
                                        <div className="flex justify-end space-x-2">
                                            <button onClick={() => setRespondingTo(null)} className="px-3 py-1 text-sm rounded-md bg-gray-200 hover:bg-gray-300 dark:bg-gray-600 dark:text-gray-200 dark:hover:bg-gray-500">Cancel</button>
                                            <button onClick={() => handleRespond(q.id)} className="px-3 py-1 text-sm rounded-md bg-indigo-600 text-white hover:bg-indigo-700">Send</button>
                                        </div>
                                    </div>
                                ) : (
                                    <button onClick={() => setRespondingTo(q.id)} className="text-indigo-600 dark:text-indigo-400 font-semibold hover:underline">
                                        Respond
                                    </button>
                                )}
                            </div>
                        )}

                        {q.response && (
                             <div className="mt-4 pt-3 border-t border-gray-200 dark:border-gray-600">
                                <p className="font-semibold text-indigo-700 dark:text-indigo-400">Your Response:</p>
                                <p className="text-gray-600 dark:text-gray-300">{q.response}</p>
                             </div>
                        )}

                    </Card>
                )) : <Card><p className="text-center text-gray-500 dark:text-gray-400 py-8">No queries assigned to you.</p></Card>}
            </div>
        </div>
    );

    return isStudent ? renderStudentView() : renderStaffAdminView();
};

export default Queries;