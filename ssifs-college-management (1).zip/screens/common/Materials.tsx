import React, { useContext, useState, useMemo } from 'react';
import { AppContext } from '../../context/AppContext';
import { UserRole, ClassroomMaterial } from '../../types';
import Card from '../../components/common/Card';

const Materials: React.FC = () => {
    const { state, dispatch } = useContext(AppContext);
    const { currentUser, materials, timetable } = state;

    const isStaff = currentUser?.role === UserRole.STAFF;

    // Form state for staff
    const [subject, setSubject] = useState('');
    const [title, setTitle] = useState('');
    const [description, setDescription] = useState('');
    
    const mySubjects = useMemo(() => {
        return [...new Set(timetable.filter(t => t.assignedTo === currentUser?.id).map(t => t.subject))];
    }, [timetable, currentUser]);

    const handleUpload = (e: React.FormEvent) => {
        e.preventDefault();
        if (!currentUser) return;
        const newMaterial: ClassroomMaterial = {
            id: `mat_${Date.now()}`,
            subject,
            title,
            description,
            fileUrl: '#', // Dummy URL
            uploadedBy: currentUser.id,
            uploaderName: currentUser.name,
            uploadDate: new Date().toISOString().split('T')[0],
        };
        dispatch({ type: 'UPLOAD_MATERIAL', payload: newMaterial });
        dispatch({ type: 'SET_NOTIFICATION', payload: { message: 'Material uploaded!', type: 'success' } });
        setSubject(''); setTitle(''); setDescription('');
    };

    return (
        <div className="space-y-6">
            <h2 className="text-2xl font-semibold text-gray-800 dark:text-gray-100">Classroom Materials</h2>

            {isStaff && (
                <Card>
                    <form onSubmit={handleUpload} className="space-y-4">
                        <h3 className="text-lg font-semibold dark:text-gray-200">Upload New Material</h3>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                           <div>
                                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Subject</label>
                                <select value={subject} onChange={e => setSubject(e.target.value)} required className="mt-1 block w-full border-gray-300 dark:border-gray-600 rounded-md shadow-sm bg-white dark:bg-gray-700 dark:text-white">
                                    <option value="">Select Subject</option>
                                    {mySubjects.map(s => <option key={s} value={s}>{s}</option>)}
                                </select>
                           </div>
                           <div>
                                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Title</label>
                                <input type="text" value={title} onChange={e => setTitle(e.target.value)} required className="mt-1 block w-full border-gray-300 dark:border-gray-600 rounded-md shadow-sm bg-white dark:bg-gray-700 dark:text-white" />
                           </div>
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Description</label>
                            <textarea value={description} onChange={e => setDescription(e.target.value)} required className="mt-1 block w-full border-gray-300 dark:border-gray-600 rounded-md shadow-sm bg-white dark:bg-gray-700 dark:text-white" />
                        </div>
                        <button type="submit" className="bg-indigo-600 text-white py-2 px-6 rounded-lg font-semibold hover:bg-indigo-700">Upload</button>
                    </form>
                </Card>
            )}

            <Card>
                <h3 className="text-xl font-semibold text-gray-800 dark:text-gray-100 mb-4">All Materials</h3>
                <div className="space-y-4">
                    {materials.length > 0 ? (
                        materials.map(material => (
                             <div key={material.id} className="p-4 bg-gray-50 dark:bg-gray-700/50 rounded-lg border dark:border-gray-600">
                                <h4 className="font-bold text-gray-800 dark:text-gray-100">{material.title}</h4>
                                <p className="text-xs text-indigo-600 dark:text-indigo-400 font-semibold mb-1">{material.subject}</p>
                                <p className="text-sm text-gray-600 dark:text-gray-300">{material.description}</p>
                                <div className="text-xs text-gray-400 dark:text-gray-500 mt-2 flex justify-between items-center">
                                    <span>By {material.uploaderName} on {material.uploadDate}</span>
                                    <a href={material.fileUrl} className="font-semibold text-indigo-600 dark:text-indigo-400 hover:underline">Download</a>
                                </div>
                            </div>
                        ))
                    ) : (
                        <p className="text-center text-gray-500 dark:text-gray-400 py-8">No materials have been uploaded.</p>
                    )}
                </div>
            </Card>
        </div>
    );
};

export default Materials;