import React, { useContext, useState, useRef } from 'react';
import { AppContext } from '../../context/AppContext';
import { UserRole, Exam, Result } from '../../types';
import Card from '../../components/common/Card';

const Exams: React.FC = () => {
    const { state, dispatch } = useContext(AppContext);
    const { currentUser, exams, results, users } = state;
    const [activeTab, setActiveTab] = useState('schedule');
    const fileInputRef = useRef<HTMLInputElement>(null);

    const isStudent = currentUser?.role === UserRole.STUDENT;
    const isStaff = currentUser?.role === UserRole.STAFF;
    const isAdmin = currentUser?.role === UserRole.ADMIN;

    // Admin state for adding exams
    const [subject, setSubject] = useState('');
    const [date, setDate] = useState('');
    const [time, setTime] = useState('');
    
    // Staff state for adding results
    const [selectedExamId, setSelectedExamId] = useState('');
    const [selectedStudentId, setSelectedStudentId] = useState('');
    const [grade, setGrade] = useState('');

    const handleAddExam = (e: React.FormEvent) => {
        e.preventDefault();
        const newExam: Exam = { id: `exam_${Date.now()}`, subject, date, time };
        dispatch({ type: 'ADD_EXAM', payload: newExam });
        dispatch({ type: 'SET_NOTIFICATION', payload: { message: 'Exam added to schedule!', type: 'success' } });
        setSubject(''); setDate(''); setTime('');
    };
    
    const handleAddResult = (e: React.FormEvent) => {
        e.preventDefault();
        const exam = exams.find(ex => ex.id === selectedExamId);
        if (!exam) return;
        
        const newResult: Result = {
            id: `res_${Date.now()}`,
            studentId: selectedStudentId,
            examId: selectedExamId,
            subject: exam.subject,
            grade,
        };
        dispatch({ type: 'ADD_RESULT', payload: newResult });
        dispatch({ type: 'SET_NOTIFICATION', payload: { message: 'Result added successfully!', type: 'success' } });
        setSelectedExamId(''); setSelectedStudentId(''); setGrade('');
    };

    const handleDownloadTemplate = () => {
        const csvContent = "data:text/csv;charset=utf-8," + "studentId,examId,grade\n" + "student01,exam01,A+";
        const encodedUri = encodeURI(csvContent);
        const link = document.createElement("a");
        link.setAttribute("href", encodedUri);
        link.setAttribute("download", "results_template.csv");
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };

    const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
        const file = event.target.files?.[0];
        if (!file) return;

        const reader = new FileReader();
        reader.onload = (e) => {
            const text = e.target?.result as string;
            const lines = text.split('\n').slice(1);
            const newResults: Result[] = lines.map((line, index) => {
                const [studentId, examId, grade] = line.split(',').map(s => s.trim());
                const exam = exams.find(ex => ex.id === examId);
                if (!studentId || !examId || !grade || !exam) return null;
                return { id: `res_csv_${Date.now()}_${index}`, studentId, examId, subject: exam.subject, grade };
            }).filter((result): result is Result => result !== null);

            if (newResults.length > 0) {
                dispatch({ type: 'BULK_ADD_RESULTS', payload: newResults });
                dispatch({ type: 'SET_NOTIFICATION', payload: { message: `${newResults.length} results uploaded!`, type: 'success' }});
            } else {
                dispatch({ type: 'SET_NOTIFICATION', payload: { message: 'CSV file is empty or invalid.', type: 'error' }});
            }
        };
        reader.readAsText(file);
    };

    const myResults = results.filter(r => r.studentId === currentUser?.id);
    const allStudents = users.filter(u => u.role === UserRole.STUDENT);

    const ScheduleView = () => (
        <Card>
            <h3 className="text-xl font-semibold text-gray-800 dark:text-gray-100 mb-4">Upcoming Exam Schedule</h3>
            <div className="space-y-3">
                {exams.sort((a,b) => new Date(a.date).getTime() - new Date(b.date).getTime()).map(exam => (
                    <div key={exam.id} className="p-4 bg-gray-50 dark:bg-gray-700/50 rounded-lg flex justify-between items-center">
                        <div>
                            <p className="font-semibold text-gray-800 dark:text-gray-200">{exam.subject}</p>
                            <p className="text-sm text-gray-500 dark:text-gray-400">{new Date(exam.date).toLocaleDateString(undefined, { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</p>
                        </div>
                        <p className="font-bold text-indigo-600 dark:text-indigo-400">{exam.time}</p>
                    </div>
                ))}
            </div>
        </Card>
    );

    return (
        <div className="space-y-6">
            <h2 className="text-2xl font-semibold text-gray-800 dark:text-gray-100">Exams & Results</h2>

            {isStudent && (
                <div className="flex space-x-2 p-1 bg-gray-200 dark:bg-gray-700 rounded-lg">
                    <button onClick={() => setActiveTab('schedule')} className={`w-full py-2 text-sm font-semibold rounded-md ${activeTab === 'schedule' ? 'bg-white dark:bg-gray-800 shadow' : 'dark:text-gray-300'}`}>Schedule</button>
                    <button onClick={() => setActiveTab('results')} className={`w-full py-2 text-sm font-semibold rounded-md ${activeTab === 'results' ? 'bg-white dark:bg-gray-800 shadow' : 'dark:text-gray-300'}`}>My Results</button>
                </div>
            )}
            
            {(!isStudent || activeTab === 'schedule') && <ScheduleView />}
            
            {isStudent && activeTab === 'results' && (
                <Card>
                    <h3 className="text-xl font-semibold text-gray-800 dark:text-gray-100 mb-4">My Results</h3>
                     <div className="space-y-3">
                        {myResults.map(result => (
                             <div key={result.id} className="p-4 bg-gray-50 dark:bg-gray-700/50 rounded-lg flex justify-between items-center">
                                <p className="font-semibold text-gray-800 dark:text-gray-200">{result.subject}</p>
                                <p className="font-bold text-2xl text-indigo-600 dark:text-indigo-400">{result.grade}</p>
                            </div>
                        ))}
                        {myResults.length === 0 && <p className="text-gray-500 dark:text-gray-400">No results published yet.</p>}
                    </div>
                </Card>
            )}

            {isAdmin && (
                <Card>
                     <form onSubmit={handleAddExam} className="space-y-4">
                        <h3 className="text-lg font-semibold dark:text-gray-200">Add New Exam</h3>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                            <input type="text" placeholder="Subject" value={subject} onChange={e => setSubject(e.target.value)} required className="border-gray-300 dark:border-gray-600 rounded-md shadow-sm bg-white dark:bg-gray-700 dark:text-white" />
                            <input type="date" value={date} onChange={e => setDate(e.target.value)} required className="border-gray-300 dark:border-gray-600 rounded-md shadow-sm bg-white dark:bg-gray-700 dark:text-white" />
                            <input type="text" placeholder="Time (e.g., 10:00 AM)" value={time} onChange={e => setTime(e.target.value)} required className="border-gray-300 dark:border-gray-600 rounded-md shadow-sm bg-white dark:bg-gray-700 dark:text-white" />
                        </div>
                        <button type="submit" className="w-full md:w-auto bg-indigo-600 text-white py-2 px-6 rounded-lg font-semibold hover:bg-indigo-700">Add Exam</button>
                    </form>
                </Card>
            )}

            {(isStaff || isAdmin) && (
                 <Card>
                     <form onSubmit={handleAddResult} className="space-y-4">
                        <div className="flex justify-between items-center">
                            <h3 className="text-lg font-semibold dark:text-gray-200">Publish Result</h3>
                             <div className="flex items-center space-x-2">
                                <button type="button" onClick={handleDownloadTemplate} className="bg-gray-600 text-white px-3 py-1.5 rounded-lg font-semibold hover:bg-gray-700 text-xs">Download Template</button>
                                <button type="button" onClick={() => fileInputRef.current?.click()} className="bg-green-600 text-white px-3 py-1.5 rounded-lg font-semibold hover:bg-green-700 text-xs">Upload Results</button>
                                <input type="file" ref={fileInputRef} onChange={handleFileUpload} accept=".csv" className="hidden" />
                            </div>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                            <select value={selectedExamId} onChange={e => setSelectedExamId(e.target.value)} required className="border-gray-300 dark:border-gray-600 rounded-md shadow-sm bg-white dark:bg-gray-700 dark:text-white"><option value="">Select Exam</option>{exams.map(ex => <option key={ex.id} value={ex.id}>{ex.subject} ({ex.date})</option>)}</select>
                            <select value={selectedStudentId} onChange={e => setSelectedStudentId(e.target.value)} required className="border-gray-300 dark:border-gray-600 rounded-md shadow-sm bg-white dark:bg-gray-700 dark:text-white"><option value="">Select Student</option>{allStudents.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}</select>
                            <input type="text" placeholder="Grade (e.g., A+)" value={grade} onChange={e => setGrade(e.target.value)} required className="border-gray-300 dark:border-gray-600 rounded-md shadow-sm bg-white dark:bg-gray-700 dark:text-white" />
                        </div>
                        <button type="submit" className="w-full md:w-auto bg-indigo-600 text-white py-2 px-6 rounded-lg font-semibold hover:bg-indigo-700">Publish Result</button>
                    </form>
                </Card>
            )}
        </div>
    );
};

export default Exams;