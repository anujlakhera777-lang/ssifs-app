
import React, { useContext } from 'react';
import { AppContext } from '../../context/AppContext';
import { TaskStatus } from '../../types';
import Card from '../../components/common/Card';

const StudentDashboard: React.FC = () => {
    const { state } = useContext(AppContext);
    const { notices, tasks } = state;
    
    const upcomingTasks = tasks.filter(t => t.status === TaskStatus.APPROVED).slice(0, 3);
    const recentNotices = notices.slice(0, 2);

    return (
        <div className="space-y-6">
            <div>
                <h2 className="text-2xl font-semibold text-gray-800 dark:text-gray-100 mb-4">Dashboard</h2>
            </div>
            
            <Card>
                <h3 className="text-lg font-semibold text-gray-700 dark:text-gray-200 mb-3">Recent Notices</h3>
                <div className="space-y-4">
                    {recentNotices.length > 0 ? (
                        recentNotices.map(notice => (
                            <div key={notice.id} className="p-4 bg-indigo-50 dark:bg-indigo-900/30 rounded-lg border border-indigo-200 dark:border-indigo-800">
                                <h4 className="font-bold text-indigo-800 dark:text-indigo-300">{notice.title}</h4>
                                <p className="text-sm text-gray-600 dark:text-gray-300 mt-1">{notice.content}</p>
                                <p className="text-xs text-gray-400 dark:text-gray-500 mt-2">{notice.date}</p>
                            </div>
                        ))
                    ) : (
                        <p className="text-sm text-gray-500 dark:text-gray-400">No new notices.</p>
                    )}
                </div>
            </Card>

            <Card>
                <h3 className="text-lg font-semibold text-gray-700 dark:text-gray-200 mb-3">Upcoming Tasks</h3>
                 <div className="space-y-3">
                    {upcomingTasks.length > 0 ? (
                        upcomingTasks.map(task => (
                            <div key={task.id} className="border-l-4 border-indigo-500 pl-4 py-2">
                                <p className="font-semibold text-gray-800 dark:text-gray-100">{task.title}</p>
                                <p className="text-sm text-gray-500 dark:text-gray-400">Due: {task.dueDate}</p>
                            </div>
                        ))
                    ) : (
                        <p className="text-sm text-gray-500 dark:text-gray-400">No upcoming tasks.</p>
                    )}
                </div>
            </Card>
        </div>
    );
};

export default StudentDashboard;