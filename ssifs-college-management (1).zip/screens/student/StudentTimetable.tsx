
import React, { useContext, useState } from 'react';
import { AppContext } from '../../context/AppContext';
import { TimetableEntry } from '../../types';
import Card from '../../components/common/Card';

type Day = 'Monday' | 'Tuesday' | 'Wednesday' | 'Thursday' | 'Friday';
const days: Day[] = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];

const TimetableCard: React.FC<{ entry: TimetableEntry }> = ({ entry }) => {
    const { state } = useContext(AppContext);
    const staff = state.users.find(u => u.id === entry.assignedTo);
    return (
        <div className="p-4 bg-gray-50 dark:bg-gray-700/50 rounded-lg border border-gray-200 dark:border-gray-600">
            <p className="font-semibold text-gray-800 dark:text-gray-100">{entry.subject}</p>
            <p className="text-sm text-indigo-600 dark:text-indigo-400">{entry.time}</p>
            {staff && <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">by {staff.name}</p>}
        </div>
    );
};

const StudentTimetable: React.FC = () => {
    const { state } = useContext(AppContext);
    const [selectedDay, setSelectedDay] = useState<Day>(days[0]);

    const entriesForDay = state.timetable.filter(entry => entry.day === selectedDay);

    return (
        <div>
            <h2 className="text-2xl font-semibold text-gray-800 dark:text-gray-100 mb-4">Class Timetable</h2>
            
            <div className="mb-6">
                <div className="flex space-x-2 p-1 bg-gray-200 dark:bg-gray-700 rounded-lg">
                    {days.map(day => (
                        <button
                            key={day}
                            onClick={() => setSelectedDay(day)}
                            className={`w-full py-2 text-sm font-semibold rounded-md transition-colors ${
                                selectedDay === day ? 'bg-white dark:bg-gray-800 shadow text-indigo-600 dark:text-indigo-300' : 'text-gray-600 dark:text-gray-300'
                            }`}
                        >
                            {day.substring(0,3)}
                        </button>
                    ))}
                </div>
            </div>

            <Card>
                <h3 className="text-lg font-bold text-gray-700 dark:text-gray-200 mb-4">{selectedDay}</h3>
                <div className="space-y-4">
                    {entriesForDay.length > 0 ? (
                        entriesForDay
                            .sort((a,b) => a.time.localeCompare(b.time))
                            .map(entry => <TimetableCard key={entry.id} entry={entry} />)
                    ) : (
                        <p className="text-center text-gray-500 dark:text-gray-400 py-4">No classes scheduled for today.</p>
                    )}
                </div>
            </Card>
        </div>
    );
};

export default StudentTimetable;