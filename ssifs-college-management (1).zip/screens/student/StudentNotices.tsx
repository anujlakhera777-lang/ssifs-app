
import React, { useContext } from 'react';
import { AppContext } from '../../context/AppContext';
import { Notice } from '../../types';
import Card from '../../components/common/Card';

const NoticeCard: React.FC<{ notice: Notice }> = ({ notice }) => (
    <Card className="mb-4">
        <h3 className="text-lg font-semibold text-gray-800 dark:text-gray-100">{notice.title}</h3>
        <p className="text-xs text-gray-400 dark:text-gray-500 mt-1 mb-3">{notice.date}</p>
        <p className="text-gray-600 dark:text-gray-300">{notice.content}</p>
    </Card>
);

const StudentNotices: React.FC = () => {
    const { state } = useContext(AppContext);
    // sort notices by date, newest first
    const sortedNotices = [...state.notices].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

    return (
        <div className="space-y-6">
            <div>
                <h2 className="text-2xl font-semibold text-gray-800 dark:text-gray-100 mb-4">All Notices</h2>
            </div>
            {sortedNotices.length > 0 ? (
                sortedNotices.map(notice => <NoticeCard key={notice.id} notice={notice} />)
            ) : (
                <Card>
                    <p className="text-center text-gray-500 dark:text-gray-400">No notices have been posted yet.</p>
                </Card>
            )}
        </div>
    );
};

export default StudentNotices;