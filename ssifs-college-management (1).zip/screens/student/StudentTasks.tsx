
import React, { useContext } from 'react';
import { AppContext } from '../../context/AppContext';
import { Task, TaskStatus } from '../../types';
import Card from '../../components/common/Card';

const TaskCard: React.FC<{ task: Task }> = ({ task }) => (
    <Card className="mb-4">
        <div className="flex justify-between items-start">
            <div>
                <h3 className="text-lg font-semibold text-gray-800 dark:text-gray-100">{task.title}</h3>
                <p className="text-sm text-gray-500 dark:text-gray-400">from {task.creatorName}</p>
            </div>
            <span className="text-xs font-medium text-white bg-indigo-600 px-2 py-1 rounded-full">
                Due: {task.dueDate}
            </span>
        </div>
        <p className="mt-3 text-gray-600 dark:text-gray-300">{task.description}</p>
    </Card>
);

const StudentTasks: React.FC = () => {
    const { state } = useContext(AppContext);
    const approvedTasks = state.tasks.filter(t => t.status === TaskStatus.APPROVED);

    return (
        <div className="space-y-6">
            <div>
                <h2 className="text-2xl font-semibold text-gray-800 dark:text-gray-100 mb-4">My Tasks</h2>
            </div>
            {approvedTasks.length > 0 ? (
                approvedTasks.map(task => <TaskCard key={task.id} task={task} />)
            ) : (
                <Card>
                    <p className="text-center text-gray-500 dark:text-gray-400">No tasks assigned yet.</p>
                </Card>
            )}
        </div>
    );
};

export default StudentTasks;