import React, { useContext } from 'react';
import { AppContext } from '../../context/AppContext';
import { TaskStatus, QueryStatus, TimetableEntry } from '../../types';
import Card from '../../components/common/Card';

const StatCard: React.FC<{ title: string; value: number; color: string }> = ({ title, value, color }) => (
    <Card className={`border-l-4 ${color}`}>
        <p className="text-sm text-gray-500 dark:text-gray-400">{title}</p>
        <p className="text-3xl font-bold text-gray-800 dark:text-gray-100">{value}</p>
    </Card>
);

const StaffDashboard: React.FC = () => {
    const { state } = useContext(AppContext);
    const { currentUser, tasks, queries, timetable } = state;
    
    // Task Stats
    const myTasks = tasks.filter(t => t.createdBy === currentUser?.id);
    const pendingCount = myTasks.filter(t => t.status === TaskStatus.PENDING).length;
    const approvedCount = myTasks.filter(t => t.status === TaskStatus.APPROVED).length;

    // Query Stats
    const myPendingQueries = queries.filter(q => (q.recipientId === currentUser?.id || q.recipientId === 'all_faculty') && q.status === QueryStatus.PENDING);

    // Timetable for today
    const today = new Date().toLocaleString('en-us', { weekday: 'long' });
    const todaysSchedule = timetable
        .filter(entry => entry.assignedTo === currentUser?.id && entry.day === today)
        .sort((a,b) => a.time.localeCompare(b.time));

    return (
        <div className="space-y-6">
            <div>
                <h2 className="text-2xl font-semibold text-gray-800 dark:text-gray-100 mb-4">Faculty Dashboard</h2>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <StatCard title="Tasks Pending" value={pendingCount} color="border-yellow-400" />
                <StatCard title="Tasks Approved" value={approvedCount} color="border-green-400" />
                <StatCard title="Queries to Answer" value={myPendingQueries.length} color="border-blue-400" />
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                 <Card>
                    <h3 className="text-lg font-semibold text-gray-700 dark:text-gray-200 mb-3">Today's Schedule ({today})</h3>
                    <div className="space-y-3">
                        {todaysSchedule.length > 0 ? (
                            todaysSchedule.map((entry: TimetableEntry) => (
                                <div key={entry.id} className="p-3 bg-indigo-50 dark:bg-indigo-900/40 rounded-lg">
                                    <p className="font-semibold text-indigo-800 dark:text-indigo-300">{entry.subject}</p>
                                    <p className="text-sm text-gray-600 dark:text-gray-400">{entry.time}</p>
                                </div>
                            ))
                        ) : (
                             <p className="text-sm text-gray-500 dark:text-gray-400 text-center py-4">No classes scheduled for today.</p>
                        )}
                    </div>
                </Card>

                 <Card>
                    <h3 className="text-lg font-semibold text-gray-700 dark:text-gray-200 mb-3">Recent Pending Queries</h3>
                    <div className="space-y-3">
                        {myPendingQueries.slice(0, 3).map(query => (
                             <div key={query.id} className="p-3 bg-gray-50 dark:bg-gray-700/60 rounded-md">
                                <div>
                                    <p className="font-medium text-gray-800 dark:text-gray-200 truncate">{query.subject}</p>
                                    <p className="text-xs text-gray-500 dark:text-gray-400">From: {query.studentName}</p>
                                </div>
                            </div>
                        ))}
                         {myPendingQueries.length === 0 && <p className="text-sm text-gray-500 dark:text-gray-400">No pending queries.</p>}
                    </div>
                </Card>
            </div>
        </div>
    );
};

export default StaffDashboard;