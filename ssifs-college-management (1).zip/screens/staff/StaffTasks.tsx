
import React, { useContext, useState } from 'react';
import { AppContext } from '../../context/AppContext';
import { Task, TaskStatus } from '../../types';
import Card from '../../components/common/Card';

const StaffTasks: React.FC = () => {
    const { state, dispatch } = useContext(AppContext);
    const { currentUser } = state;

    const [title, setTitle] = useState('');
    const [description, setDescription] = useState('');
    const [dueDate, setDueDate] = useState('');
    const [showForm, setShowForm] = useState(false);

    const myTasks = state.tasks.filter(t => t.createdBy === currentUser?.id);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!title || !description || !dueDate || !currentUser) return;

        const newTask: Task = {
            id: `task_${Date.now()}`,
            title,
            description,
            dueDate,
            status: TaskStatus.PENDING,
            createdBy: currentUser.id,
            creatorName: currentUser.name,
        };
        dispatch({ type: 'ADD_TASK', payload: newTask });
        dispatch({ type: 'SET_NOTIFICATION', payload: { message: 'Task submitted for approval!', type: 'success' } });
        setTitle('');
        setDescription('');
        setDueDate('');
        setShowForm(false);
    };

    return (
        <div className="space-y-6">
            <div className="flex justify-between items-center">
                <h2 className="text-2xl font-semibold text-gray-800 dark:text-gray-100">My Tasks</h2>
                <button
                    onClick={() => setShowForm(!showForm)}
                    className="bg-indigo-600 text-white px-4 py-2 rounded-lg font-semibold hover:bg-indigo-700 transition-colors"
                >
                    {showForm ? 'Cancel' : '+ New Task'}
                </button>
            </div>

            {showForm && (
                <Card>
                    <form onSubmit={handleSubmit} className="space-y-4">
                        <h3 className="text-lg font-semibold dark:text-gray-200">Create New Task</h3>
                        <div>
                            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Title</label>
                            <input type="text" value={title} onChange={e => setTitle(e.target.value)} required className="mt-1 block w-full border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 bg-white dark:bg-gray-700 dark:text-white" />
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Description</label>
                            <textarea value={description} onChange={e => setDescription(e.target.value)} required className="mt-1 block w-full border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 bg-white dark:bg-gray-700 dark:text-white" />
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Due Date</label>
                            <input type="date" value={dueDate} onChange={e => setDueDate(e.target.value)} required className="mt-1 block w-full border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 bg-white dark:bg-gray-700 dark:text-white" />
                        </div>
                        <button type="submit" className="w-full bg-indigo-600 text-white py-2 rounded-lg font-semibold hover:bg-indigo-700">Submit for Approval</button>
                    </form>
                </Card>
            )}

            <div className="space-y-4">
                {myTasks.length > 0 ? (
                    myTasks.map(task => (
                        <Card key={task.id}>
                            <div className="flex justify-between items-start">
                                <div>
                                    <h3 className="font-semibold dark:text-gray-100">{task.title}</h3>
                                    <p className="text-sm text-gray-500 dark:text-gray-400">Due: {task.dueDate}</p>
                                </div>
                                <span className={`px-2 py-1 text-xs font-semibold rounded-full ${
                                    task.status === TaskStatus.APPROVED ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200' :
                                    task.status === TaskStatus.PENDING ? 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200' :
                                    'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200'
                                }`}>
                                    {task.status}
                                </span>
                            </div>
                        </Card>
                    ))
                ) : (
                    <Card><p className="text-center text-gray-500 dark:text-gray-400">You haven't created any tasks yet.</p></Card>
                )}
            </div>
        </div>
    );
};

export default StaffTasks;