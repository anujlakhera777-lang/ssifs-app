
import React, { useContext } from 'react';
import { AppContext } from '../../context/AppContext';
import Card from '../../components/common/Card';

const StaffTimetable: React.FC = () => {
    const { state } = useContext(AppContext);
    const { currentUser, timetable } = state;
    const mySchedule = timetable.filter(entry => entry.assignedTo === currentUser?.id);
    const days: string[] = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];

    return (
        <div>
            <h2 className="text-2xl font-semibold text-gray-800 dark:text-gray-100 mb-4">My Teaching Schedule</h2>
            <div className="space-y-6">
                {days.map(day => {
                    const entriesForDay = mySchedule
                        .filter(entry => entry.day === day)
                        .sort((a, b) => a.time.localeCompare(b.time));

                    if (entriesForDay.length === 0) return null;

                    return (
                        <Card key={day}>
                            <h3 className="text-lg font-bold text-gray-700 dark:text-gray-200 mb-4">{day}</h3>
                            <div className="space-y-3">
                                {entriesForDay.map(entry => (
                                    <div key={entry.id} className="p-3 bg-indigo-50 dark:bg-indigo-900/40 rounded-lg">
                                        <p className="font-semibold text-indigo-800 dark:text-indigo-300">{entry.subject}</p>
                                        <p className="text-sm text-gray-600 dark:text-gray-400">{entry.time}</p>
                                    </div>
                                ))}
                            </div>
                        </Card>
                    );
                })}
                 {mySchedule.length === 0 && <Card><p className="text-center text-gray-500 dark:text-gray-400 py-4">You have no classes scheduled.</p></Card>}
            </div>
        </div>
    );
};

export default StaffTimetable;