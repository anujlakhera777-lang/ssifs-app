
import React, { useContext } from 'react';
import { AppContext } from '../../context/AppContext';
import { Task, TaskStatus } from '../../types';
import Card from '../../components/common/Card';

const AdminTaskApproval: React.FC = () => {
    const { state, dispatch } = useContext(AppContext);
    const pendingTasks = state.tasks.filter(t => t.status === TaskStatus.PENDING);

    const handleUpdateStatus = (taskId: string, status: TaskStatus) => {
        dispatch({ type: 'UPDATE_TASK_STATUS', payload: { taskId, status } });
        dispatch({ type: 'SET_NOTIFICATION', payload: { message: `Task has been ${status.toLowerCase()}.`, type: 'success' } });
    };

    return (
        <Card>
            <h2 className="text-xl font-semibold text-gray-800 dark:text-gray-100 mb-6">Task Approval Queue</h2>
            <div className="space-y-4">
                {pendingTasks.length > 0 ? (
                    pendingTasks.map(task => (
                        <div key={task.id} className="p-4 rounded-lg border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800">
                            <div className="flex justify-between items-start">
                                <div>
                                    <h3 className="text-lg font-semibold text-gray-800 dark:text-gray-100">{task.title}</h3>
                                    <p className="text-sm text-gray-500 dark:text-gray-400">Submitted by: {task.creatorName}</p>
                                    <p className="text-sm text-gray-500 dark:text-gray-400">Due Date: {task.dueDate}</p>
                                </div>
                                <div className="flex space-x-2">
                                    <button
                                        onClick={() => handleUpdateStatus(task.id, TaskStatus.APPROVED)}
                                        className="px-3 py-1 text-sm font-medium text-green-700 bg-green-100 rounded-md hover:bg-green-200 dark:bg-green-900 dark:text-green-200 dark:hover:bg-green-800"
                                    >
                                        Approve
                                    </button>
                                    <button
                                        onClick={() => handleUpdateStatus(task.id, TaskStatus.REJECTED)}
                                        className="px-3 py-1 text-sm font-medium text-red-700 bg-red-100 rounded-md hover:bg-red-200 dark:bg-red-900 dark:text-red-200 dark:hover:bg-red-800"
                                    >
                                        Reject
                                    </button>
                                </div>
                            </div>
                            <p className="mt-3 text-gray-600 dark:text-gray-300 border-t border-gray-200 dark:border-gray-700 pt-3">{task.description}</p>
                        </div>
                    ))
                ) : (
                    <p className="text-center text-gray-500 dark:text-gray-400 py-8">No tasks are currently pending approval.</p>
                )}
            </div>
        </Card>
    );
};

export default AdminTaskApproval;