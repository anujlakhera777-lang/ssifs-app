import React, { useState, useContext, useRef } from 'react';
import { AppContext } from '../../context/AppContext';
import { UserRole, TimetableEntry } from '../../types';
import Card from '../../components/common/Card';

type Day = 'Monday' | 'Tuesday' | 'Wednesday' | 'Thursday' | 'Friday';
const days: Day[] = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];

const AdminTimetable: React.FC = () => {
    const { state, dispatch } = useContext(AppContext);
    const staffMembers = state.users.filter(u => u.role === UserRole.STAFF);
    const [isModalOpen, setIsModalOpen] = useState(false);

    const [day, setDay] = useState<Day>('Monday');
    const [time, setTime] = useState('');
    const [subject, setSubject] = useState('');
    const [assignedTo, setAssignedTo] = useState('');

    const fileInputRef = useRef<HTMLInputElement>(null);

    const resetForm = () => {
        setDay('Monday');
        setTime('');
        setSubject('');
        setAssignedTo('');
    }

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if(!day || !time || !subject || !assignedTo) return;

        const newEntry: TimetableEntry = {
            id: `tt_${Date.now()}`,
            day,
            time,
            subject,
            assignedTo,
            type: 'class' // Simplified
        };
        dispatch({ type: 'UPDATE_TIMETABLE', payload: newEntry });
        dispatch({ type: 'SET_NOTIFICATION', payload: { message: 'Timetable updated successfully!', type: 'success' } });
        resetForm();
        setIsModalOpen(false);
    };

    const handleDownloadTemplate = () => {
        const csvContent = "data:text/csv;charset=utf-8," 
            + "day,time,subject,assignedToId,type\n"
            + "Monday,10:00 - 11:30,Fashion History,staff01,class";
        const encodedUri = encodeURI(csvContent);
        const link = document.createElement("a");
        link.setAttribute("href", encodedUri);
        link.setAttribute("download", "timetable_template.csv");
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };

    const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
        const file = event.target.files?.[0];
        if (!file) return;

        const reader = new FileReader();
        reader.onload = (e) => {
            const text = e.target?.result as string;
            const lines = text.split('\n').slice(1); // ignore header
            const newTimetable: TimetableEntry[] = lines.map((line, index) => {
                const [day, time, subject, assignedTo, type] = line.split(',').map(s => s.trim());
                if (!day || !time || !subject || !assignedTo) return null;
                return { id: `tt_csv_${Date.now()}_${index}`, day, time, subject, assignedTo, type: type === 'lab' ? 'lab' : 'class' } as TimetableEntry;
            }).filter((entry): entry is TimetableEntry => entry !== null);

            if (newTimetable.length > 0) {
                dispatch({ type: 'BULK_UPDATE_TIMETABLE', payload: newTimetable });
                dispatch({ type: 'SET_NOTIFICATION', payload: { message: 'Timetable uploaded successfully!', type: 'success' }});
            } else {
                dispatch({ type: 'SET_NOTIFICATION', payload: { message: 'CSV file is empty or invalid.', type: 'error' }});
            }
        };
        reader.readAsText(file);
    };

    return (
        <div className="space-y-6">
             <div className="flex justify-between items-center flex-wrap gap-4">
                 <div className="flex items-center space-x-2">
                    <button onClick={handleDownloadTemplate} className="bg-gray-600 text-white px-4 py-2 rounded-lg font-semibold hover:bg-gray-700 transition-colors text-sm">Download Template</button>
                    <button onClick={() => fileInputRef.current?.click()} className="bg-green-600 text-white px-4 py-2 rounded-lg font-semibold hover:bg-green-700 transition-colors text-sm">Upload CSV</button>
                    <input type="file" ref={fileInputRef} onChange={handleFileUpload} accept=".csv" className="hidden" />
                </div>
                <button
                    onClick={() => setIsModalOpen(true)}
                    className="bg-indigo-600 text-white px-5 py-2.5 rounded-lg font-semibold hover:bg-indigo-700 transition-all shadow-sm hover:shadow-md flex items-center space-x-2"
                >
                    <PlusIcon />
                    <span>Add Schedule Entry</span>
                </button>
            </div>

            <Card>
                <h3 className="text-xl font-semibold text-gray-800 dark:text-gray-100 mb-4">Full Timetable</h3>
                <div className="space-y-6">
                    {days.map(d => {
                        const dayEntries = state.timetable.filter(t => t.day === d).sort((a,b) => a.time.localeCompare(b.time));
                        if (dayEntries.length === 0) return null;

                        return (
                            <div key={d}>
                                <h4 className="font-bold text-gray-600 dark:text-gray-300 pb-2 border-b-2 border-indigo-200 dark:border-indigo-800 mb-3">{d}</h4>
                                <div className="space-y-2">
                                    {dayEntries.map(entry => (
                                        <div key={entry.id} className="p-3 bg-gray-50 dark:bg-gray-700/50 rounded-lg border border-gray-200 dark:border-gray-600 hover:border-indigo-300 hover:bg-indigo-50 dark:hover:bg-indigo-900/40 transition-all">
                                            <div className="flex justify-between items-center">
                                                <div>
                                                    <span className="font-semibold text-indigo-700 dark:text-indigo-400 w-28 inline-block">{entry.time}:</span>
                                                    <span className="ml-2 font-medium text-gray-800 dark:text-gray-200">{entry.subject}</span>
                                                </div>
                                                <span className="text-gray-500 dark:text-gray-400 text-sm">{staffMembers.find(s => s.id === entry.assignedTo)?.name || 'N/A'}</span>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        )
                    })}
                </div>
            </Card>

            {isModalOpen && (
                <div className="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center z-50 transition-opacity" aria-modal="true" role="dialog">
                    <div className="bg-white dark:bg-gray-800 p-8 rounded-2xl shadow-xl w-full max-w-md m-4 transform transition-all duration-300 scale-95 opacity-0 animate-fade-in-scale" style={{ animation: 'fade-in-scale 0.3s forwards' }}>
                        <form onSubmit={handleSubmit} className="space-y-4">
                            <div className="flex justify-between items-center pb-3 border-b border-gray-200 dark:border-gray-700">
                                <h3 className="text-xl font-semibold text-gray-800 dark:text-gray-100">Add Schedule Entry</h3>
                                <button type="button" onClick={() => setIsModalOpen(false)} className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 rounded-full p-1 focus:outline-none focus:ring-2 focus:ring-indigo-500">
                                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" /></svg>
                                </button>
                            </div>
                            
                            <div className="pt-4 space-y-4">
                                <div>
                                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Day</label>
                                    <select value={day} onChange={e => setDay(e.target.value as Day)} className="mt-1 block w-full border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 py-2 px-3 bg-white dark:bg-gray-700 dark:text-white">
                                        {days.map(d => <option key={d} value={d}>{d}</option>)}
                                    </select>
                                </div>
                                <div>
                                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Time (e.g., 10:00 - 11:30)</label>
                                    <input type="text" placeholder="10:00 - 11:30" value={time} onChange={e => setTime(e.target.value)} required className="mt-1 block w-full border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 bg-white dark:bg-gray-700 dark:text-white" />
                                </div>
                                <div>
                                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Subject</label>
                                    <input type="text" placeholder="Fashion History" value={subject} onChange={e => setSubject(e.target.value)} required className="mt-1 block w-full border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 bg-white dark:bg-gray-700 dark:text-white" />
                                </div>
                                <div>
                                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Assign to Staff</label>
                                    <select value={assignedTo} onChange={e => setAssignedTo(e.target.value)} required className="mt-1 block w-full border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 py-2 px-3 bg-white dark:bg-gray-700 dark:text-white">
                                        <option value="">Select Staff</option>
                                        {staffMembers.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
                                    </select>
                                </div>
                            </div>

                            <div className="flex justify-end space-x-3 pt-6">
                                <button type="button" onClick={() => setIsModalOpen(false)} className="px-5 py-2.5 rounded-lg text-gray-700 dark:text-gray-200 bg-gray-100 dark:bg-gray-600 hover:bg-gray-200 dark:hover:bg-gray-500 font-semibold transition-colors">Cancel</button>
                                <button type="submit" className="px-5 py-2.5 bg-indigo-600 text-white rounded-lg font-semibold hover:bg-indigo-700 transition-colors">Add Entry</button>
                            </div>
                        </form>
                    </div>
                    <style>{`
                        @keyframes fade-in-scale {
                            from { opacity: 0; transform: scale(0.95); }
                            to { opacity: 1; transform: scale(1); }
                        }
                        .animate-fade-in-scale {
                            animation: fade-in-scale 0.2s ease-out forwards;
                        }
                    `}</style>
                </div>
            )}
        </div>
    );
};

const PlusIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v12m6-6H6" /></svg>;

export default AdminTimetable;