import React, { useState, useContext, useRef } from 'react';
import { AppContext } from '../../context/AppContext';
import { User, UserRole } from '../../types';
import Card from '../../components/common/Card';

const AdminUserManagement: React.FC = () => {
    const { state, dispatch } = useContext(AppContext);
    const [selectedUser, setSelectedUser] = useState<User | null>(null);
    const [isEditModalOpen, setIsEditModalOpen] = useState(false);
    const [newRole, setNewRole] = useState<UserRole>(UserRole.STUDENT);
    const fileInputRef = useRef<HTMLInputElement>(null);

    const students = state.users.filter(u => u.role === UserRole.STUDENT);
    const staff = state.users.filter(u => u.role === UserRole.STAFF);

    const openEditModal = (user: User) => {
        setSelectedUser(user);
        setNewRole(user.role);
        setIsEditModalOpen(true);
    };

    const handleRoleChange = () => {
        if (!selectedUser) return;
        dispatch({ type: 'UPDATE_USER_ROLE', payload: { userId: selectedUser.id, newRole } });
        dispatch({ type: 'SET_NOTIFICATION', payload: { message: `User role updated to ${newRole}.`, type: 'success' } });
        setIsEditModalOpen(false);
    };

    const handlePasswordReset = () => {
        if (!selectedUser) return;
        if (window.confirm(`Are you sure you want to reset the password for ${selectedUser.name}? The new password will be 'password123'.`)) {
            dispatch({ type: 'UPDATE_USER_PASSWORD', payload: { userId: selectedUser.id, newPassword: 'password123' } });
            dispatch({ type: 'SET_NOTIFICATION', payload: { message: 'Password reset successfully.', type: 'success' } });
            setIsEditModalOpen(false);
        }
    };

    const handleRemoveUser = (userId: string) => {
        if (window.confirm('Are you sure you want to remove this user?')) {
            dispatch({ type: 'REMOVE_USER', payload: { userId } });
            dispatch({ type: 'SET_NOTIFICATION', payload: { message: `User removed.`, type: 'success' } });
        }
    };

    const handleDownloadTemplate = () => {
        const csvContent = "data:text/csv;charset=utf-8," + "name,email,password,role\n" + "John Doe,john.d@ssifs.edu,password123,Student";
        const encodedUri = encodeURI(csvContent);
        const link = document.createElement("a");
        link.setAttribute("href", encodedUri);
        link.setAttribute("download", "user_template.csv");
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };

    const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
        const file = event.target.files?.[0];
        if (!file) return;
        const reader = new FileReader();
        reader.onload = (e) => {
            const text = e.target?.result as string;
            const lines = text.split('\n').slice(1);
            const newUsers: User[] = lines.map((line, index) => {
                const [name, email, password, role] = line.split(',').map(s => s.trim());
                if (!name || !email || !password || !role) return null;
                return { id: `user_csv_${Date.now()}_${index}`, name, email, password, role: role as UserRole };
            }).filter((user): user is User => user !== null);

            if (newUsers.length > 0) {
                dispatch({ type: 'BULK_ADD_USERS', payload: newUsers });
                dispatch({ type: 'SET_NOTIFICATION', payload: { message: `${newUsers.length} users uploaded successfully!`, type: 'success' }});
            } else {
                 dispatch({ type: 'SET_NOTIFICATION', payload: { message: 'CSV file is empty or invalid.', type: 'error' }});
            }
        };
        reader.readAsText(file);
    };

    return (
        <div className="space-y-8">
            <Card>
                <div className="flex justify-between items-center">
                    <h3 className="text-lg font-semibold text-gray-700 dark:text-gray-200">Bulk Management</h3>
                     <div className="flex items-center space-x-2">
                        <button onClick={handleDownloadTemplate} className="bg-gray-600 text-white px-4 py-2 rounded-lg font-semibold hover:bg-gray-700 transition-colors text-sm">Download Template</button>
                        <button onClick={() => fileInputRef.current?.click()} className="bg-green-600 text-white px-4 py-2 rounded-lg font-semibold hover:bg-green-700 transition-colors text-sm">Upload Users CSV</button>
                        <input type="file" ref={fileInputRef} onChange={handleFileUpload} accept=".csv" className="hidden" />
                    </div>
                </div>
            </Card>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <UserList title="Student List" users={students} onRemoveUser={handleRemoveUser} onEditUser={openEditModal} />
                <UserList title="Staff List" users={staff} onRemoveUser={handleRemoveUser} onEditUser={openEditModal} />
            </div>

            {isEditModalOpen && selectedUser && (
                 <div className="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center z-50">
                    <Card className="w-full max-w-md">
                        <h3 className="text-xl font-semibold mb-4 dark:text-gray-100">Edit User: {selectedUser.name}</h3>
                        <div className="space-y-4">
                            <div>
                                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Change Role</label>
                                <select value={newRole} onChange={e => setNewRole(e.target.value as UserRole)} className="mt-1 block w-full border-gray-300 dark:border-gray-600 rounded-md shadow-sm bg-white dark:bg-gray-700 dark:text-white">
                                    <option value={UserRole.STUDENT}>Student</option>
                                    <option value={UserRole.STAFF}>Staff</option>
                                    <option value={UserRole.ADMIN}>Admin</option>
                                </select>
                            </div>
                            <button onClick={handleRoleChange} className="w-full bg-indigo-600 text-white py-2 rounded-lg font-semibold hover:bg-indigo-700">Save Role</button>
                            <div className="mt-4 pt-4 border-t dark:border-gray-700">
                                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Actions</label>
                                <button onClick={handlePasswordReset} className="mt-1 w-full bg-red-600 text-white py-2 rounded-lg font-semibold hover:bg-red-700">Reset Password</button>
                            </div>
                        </div>
                        <button onClick={() => setIsEditModalOpen(false)} className="mt-6 w-full bg-gray-200 text-gray-700 dark:bg-gray-600 dark:text-gray-200 py-2 rounded-lg font-semibold hover:bg-gray-300 dark:hover:bg-gray-500">Cancel</button>
                    </Card>
                </div>
            )}
        </div>
    );
};

const UserList: React.FC<{ title: string; users: User[]; onRemoveUser: (userId: string) => void; onEditUser: (user: User) => void; }> = ({ title, users, onRemoveUser, onEditUser }) => (
    <Card>
        <h3 className="text-lg font-semibold text-gray-700 dark:text-gray-200 mb-4">{title}</h3>
        <div className="space-y-3 max-h-96 overflow-y-auto pr-2">
            {users.length > 0 ? (
                users.map(user => (
                    <div key={user.id} className="flex justify-between items-center p-3 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
                        <div>
                            <p className="font-medium text-gray-800 dark:text-gray-200">{user.name}</p>
                            <p className="text-sm text-gray-500 dark:text-gray-400">{user.email}</p>
                        </div>
                        <div className="flex space-x-2">
                            <button onClick={() => onEditUser(user)} className="text-blue-500 hover:text-blue-700 p-1" aria-label={`Edit ${user.name}`}><PencilIcon /></button>
                            <button onClick={() => onRemoveUser(user.id)} className="text-red-500 hover:text-red-700 p-1" aria-label={`Remove ${user.name}`}><TrashIcon /></button>
                        </div>
                    </div>
                ))
            ) : (
                <p className="text-center text-gray-500 dark:text-gray-400 py-4">No users found.</p>
            )}
        </div>
    </Card>
);

const TrashIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>;
const PencilIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.5L15.232 5.232z" /></svg>;

export default AdminUserManagement;