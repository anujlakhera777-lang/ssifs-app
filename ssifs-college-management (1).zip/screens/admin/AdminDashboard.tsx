import React, { useContext } from 'react';
import { AppContext } from '../../context/AppContext';
import { UserRole, TaskStatus, QueryStatus } from '../../types';
import Card from '../../components/common/Card';

const StatCard: React.FC<{ title: string; value: number | string; icon: React.ReactNode }> = ({ title, value, icon }) => (
    <Card className="flex items-center p-4">
        <div className="p-3 rounded-full bg-indigo-100 dark:bg-gray-700 text-indigo-600 dark:text-indigo-400 mr-4">
            {icon}
        </div>
        <div>
            <p className="text-sm text-gray-500 dark:text-gray-400 font-medium">{title}</p>
            <p className="text-2xl font-bold text-gray-800 dark:text-gray-100">{value}</p>
        </div>
    </Card>
);

const AdminDashboard: React.FC = () => {
    const { state } = useContext(AppContext);
    const studentCount = state.users.filter(u => u.role === UserRole.STUDENT).length;
    const staffCount = state.users.filter(u => u.role === UserRole.STAFF).length;
    
    // Task Analytics
    const approvedTasks = state.tasks.filter(t => t.status === TaskStatus.APPROVED).length;
    const rejectedTasks = state.tasks.filter(t => t.status === TaskStatus.REJECTED).length;
    const totalTasksEvaluated = approvedTasks + rejectedTasks;
    const approvalRate = totalTasksEvaluated > 0 ? Math.round((approvedTasks / totalTasksEvaluated) * 100) : 0;
    
    // Query Analytics
    const answeredQueries = state.queries.filter(q => q.status === QueryStatus.ANSWERED).length;
    const pendingQueries = state.queries.length - answeredQueries;
    
    // Attendance Analytics
    const today = new Date().toISOString().split('T')[0];
    const attendanceToday = state.attendance.filter(a => a.date === today).length;


    return (
        <div className="space-y-8">
            <h2 className="text-2xl font-semibold text-gray-800 dark:text-gray-100">Analytics Dashboard</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <StatCard title="Total Students" value={studentCount} icon={<UsersIcon />} />
                <StatCard title="Total Staff" value={staffCount} icon={<BriefcaseIcon />} />
                <StatCard title="Queries to Resolve" value={pendingQueries} icon={<QuestionIcon />} />
                <StatCard title="Attendance Marked Today" value={attendanceToday} icon={<CheckCircleIcon />} />
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-5 gap-8">
                <Card className="lg:col-span-3">
                    <h3 className="text-lg font-semibold text-gray-700 dark:text-gray-200 mb-4">Task Approval Status</h3>
                    <div className="space-y-4">
                        <div>
                            <div className="flex justify-between mb-1">
                                <span className="text-base font-medium text-green-700 dark:text-green-400">Approved</span>
                                <span className="text-sm font-medium text-green-700 dark:text-green-400">{approvedTasks} Tasks</span>
                            </div>
                            <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2.5">
                                <div className="bg-green-500 h-2.5 rounded-full" style={{width: `${approvalRate}%`}}></div>
                            </div>
                        </div>
                        <div>
                            <div className="flex justify-between mb-1">
                                <span className="text-base font-medium text-red-700 dark:text-red-400">Rejected</span>
                                <span className="text-sm font-medium text-red-700 dark:text-red-400">{rejectedTasks} Tasks</span>
                            </div>
                            <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2.5">
                                <div className="bg-red-500 h-2.5 rounded-full" style={{width: `${totalTasksEvaluated > 0 ? 100-approvalRate : 0}%`}}></div>
                            </div>
                        </div>
                         <p className="text-sm text-gray-500 dark:text-gray-400 pt-2">
                            <span className="font-bold">{approvalRate}%</span> of {totalTasksEvaluated} evaluated tasks have been approved.
                         </p>
                    </div>
                </Card>
                <Card className="lg:col-span-2">
                    <h3 className="text-lg font-semibold text-gray-700 dark:text-gray-200 mb-4">Query Overview</h3>
                     <div className="space-y-3 text-center">
                        <div className="p-4 bg-blue-50 dark:bg-blue-900/50 rounded-lg">
                            <p className="font-bold text-4xl text-blue-600 dark:text-blue-400">{pendingQueries}</p>
                            <p className="text-sm text-blue-800 dark:text-blue-300">Pending Queries</p>
                        </div>
                        <div className="p-4 bg-gray-50 dark:bg-gray-700 rounded-lg">
                             <p className="font-bold text-4xl text-gray-600 dark:text-gray-300">{answeredQueries}</p>
                            <p className="text-sm text-gray-800 dark:text-gray-200">Queries Answered</p>
                        </div>
                    </div>
                </Card>
            </div>
        </div>
    );
};

const UsersIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M15 21a6 6 0 00-9-5.197M15 21a6 6 0 00-9-5.197" /></svg>;
const BriefcaseIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 13.255A23.931 23.931 0 0112 15c-3.183 0-6.22-.62-9-1.745M16 6V4a2 2 0 00-2-2h-4a2 2 0 00-2 2v2m4 6h.01M5 20h14a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" /></svg>;
const QuestionIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M8.228 9c.549-1.165 2.03-2 3.772-2 2.21 0 4 1.79 4 4 0 2.21-1.79 4-4 4-1.742 0-3.223-.835-3.772-2M12 18.5v.01" /></svg>;
const CheckCircleIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2"><path strokeLinecap="round" strokeLinejoin="round" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>;

export default AdminDashboard;